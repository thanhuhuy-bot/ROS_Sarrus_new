#!/usr/bin/env bash
set -e
source /opt/ros/humble/setup.bash
source "$HOME/ros_sarrus/install/setup.bash"
exec ros2 launch as3_description view_gazebo_tcp_xyz_theta.launch.py
