#!/usr/bin/env python3
"""Offline smoke-test for WORLD TCP base-choice; no ROS installation needed."""
import math
import sys
from pathlib import Path

pkg=Path(__file__).resolve().parents[1]/'src/as3_description'
sys.path.insert(0,str(pkg/'scripts'))
from as3_auto_world_planner import candidate_stops
from as3_auto_math import world_to_base,base_to_world,navigation_step
from as3_kinematics import RobotKinematics,ARM_NAMES

kin=RobotKinematics(pkg/'urdf/as3_movable.urdf')
zero={n:0.0 for n in ARM_NAMES}
start=(0.,0.,0.11,0.)

# Close goal must not require any base movement.
close_target=(0.300,0.300,0.300)
q,err=kin.ik(world_to_base(close_target,start),zero,True,0.0002,kin.pitch_zero)
assert q is not None and err<=0.0002

# Further goal cannot be reached from start, but can after planned base move.
far_target=(0.55,0.055,0.34)
q,err=kin.ik(world_to_base(far_target,start),zero,True,0.0002,kin.pitch_zero)
assert q is None
choice=None
for ix,(bx,by,yaw) in enumerate(candidate_stops(far_target,start)[:30]):
    guess=(bx,by,start[2],yaw)
    q,err=kin.ik(world_to_base(far_target,guess),zero,True,0.0002,kin.pitch_zero)
    if q is not None:
        choice=guess
        break
assert choice is not None
assert math.hypot(choice[0],choice[1])<0.5

# Emulate EXACT planar speed model used by virtual_mobile_base.py.
x,y,z,yaw=start
phase='ALIGN'
for step in range(3000):
    phase,v,w=navigation_step((x,y,z,yaw),(choice[0],choice[1],choice[3]),phase)
    if phase=='DONE': break
    dt=1.0/30.0
    mid=yaw+0.5*w*dt
    x+=v*dt*math.cos(mid)
    y+=v*dt*math.sin(mid)
    yaw=math.atan2(math.sin(yaw+w*dt),math.cos(yaw+w*dt))
assert phase=='DONE'
q,err=kin.ik(world_to_base(far_target,(x,y,z,yaw)),zero,True,0.0002,kin.pitch_zero)
assert q is not None and err<=0.0002
computed=base_to_world(kin.fk(q),(x,y,z,yaw))
assert math.dist(computed,far_target)<=0.0002
print('PASS: unchanged-base reach; automatic base selection; navigation; recomputed WORLD TCP IK')
