#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
source /opt/ros/humble/setup.bash
colcon build --symlink-install --packages-select as3_description
source install/setup.bash
ros2 launch as3_description view_movable.launch.py demo:=true
