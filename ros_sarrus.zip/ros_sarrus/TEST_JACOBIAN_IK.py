#!/usr/bin/env python3
"""Reproducible off-line test for V4.8.5, no ROS runtime required."""
import math
import random
import sys
from pathlib import Path

import numpy as np

root=Path(__file__).resolve().parent/'src/as3_description'
sys.path.insert(0,str(root/'scripts'))
from as3_kinematics import ARM_NAMES,RobotKinematics

robot=RobotKinematics(root/'urdf/as3_movable.urdf')
random_gen=random.Random(73)
zero={n:0.0 for n in ARM_NAMES}
max_gap=0.0
for _ in range(15):
    q={n:random_gen.uniform(*robot.limits[n]) for n in ARM_NAMES}
    p,J=robot.fk_jacobian(q)
    for k,n in enumerate(ARM_NAMES):
        h=1e-6
        perturbed=dict(q)
        perturbed[n]+=h
        numerical=(np.array(robot.fk(perturbed))-p)/h
        max_gap=max(max_gap,float(np.max(np.abs(numerical-J[:,k]))))
print('Max analytical Jacobian / finite difference error:',max_gap)
assert max_gap<1e-5
for pitch_mode in (False,True):
    for allow in (False,True):
        passed=0
        for i in range(20):
            desired=dict(zero)
            desired['joint_1_sarrus']=random_gen.uniform(0,0.045) if allow else 0.0
            desired['joint_2_yaw']=random_gen.uniform(-0.7,0.7)
            desired['joint_3_shoulder']=random_gen.uniform(-0.8,0.8)
            desired['joint_4_elbow']=random_gen.uniform(-1.0,1.0)
            desired['joint_5_wrist']=random_gen.uniform(-0.9,0.9)
            target=robot.fk(desired)
            pitch=robot.pitch(desired) if pitch_mode else None
            result,err,path=robot.ik_with_path(target,zero,allow,0.0002,pitch)
            assert result is not None,(pitch_mode,allow,i,err)
            assert err<=0.0002+1e-9
            assert path[0]==zero
            for n in ARM_NAMES:
                low,high=robot.limits[n]
                assert low-1e-9<=result[n]<=high+1e-9
            if not allow:
                assert result['joint_1_sarrus']==0.0
            if pitch_mode:
                assert abs(robot.pitch(result)-pitch)<math.radians(0.5)
            passed+=1
        print(f'Mode XYZ+pitch={pitch_mode}, allow_sarrus={allow}: {passed}/20 reached (<0.2mm)')
print('All tests passed. These are offline kinematic tests, not live ROS tests.')
