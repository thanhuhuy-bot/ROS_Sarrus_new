// Gazebo Classic 11 optional visual-kinematic mirror for the unmodified ROS Assem3.
// It does not pretend to simulate closed-chain Sarrus physics or actuator torques.
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/Events.hh>
#include <gazebo_ros/node.hpp>
#include <geometry_msgs/msg/pose_array.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <rclcpp/rclcpp.hpp>
#include <ignition/math/Pose3.hh>
#include <algorithm>
#include <cmath>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace gazebo {
class As3KinematicMirror : public ModelPlugin {
 public:
  void Load(physics::ModelPtr model, sdf::ElementPtr sdf) override {
    model_ = model;
    ros_node_ = gazebo_ros::Node::Get(sdf);
    if (!ros_node_) {
      gzerr << "[As3] gazebo_ros node missing; start with gazebo_ros launch.\n";
      return;
    }
    for (const std::string &side : {"south", "east", "north", "west"}) {
      for (const std::string &which : {"lower", "upper"}) {
        const auto name = std::string("sarrus_cad_") + side + "_" + which;
        sarrus_links_.push_back(model_->GetLink(name));
        if (!sarrus_links_.back()) {
          RCLCPP_WARN(ros_node_->get_logger(), "Missing Sarrus link: %s", name.c_str());
        }
      }
    }
    // These links are kinematically driven from ROS; gravity would cause them to drift.
    for (const auto &link : model_->GetLinks()) {
      link->SetGravityMode(false);
      link->SetSelfCollide(false);
    }
    js_sub_ = ros_node_->create_subscription<sensor_msgs::msg::JointState>(
      "/joint_states", 10,
      [this](const sensor_msgs::msg::JointState::SharedPtr msg) {
        std::lock_guard<std::mutex> lk(mutex_);
        for (size_t i = 0; i < msg->name.size() && i < msg->position.size(); ++i) {
          if (std::isfinite(msg->position[i])) joint_positions_[msg->name[i]] = msg->position[i];
        }
        joints_dirty_ = true;
      });
    poses_sub_ = ros_node_->create_subscription<geometry_msgs::msg::PoseArray>(
      "/as3/gazebo/kinematic_poses", 10,
      [this](const geometry_msgs::msg::PoseArray::SharedPtr msg) {
        if (msg->poses.size() != 9 || msg->header.frame_id != "world") return;
        std::lock_guard<std::mutex> lk(mutex_);
        poses_ = msg->poses;
        poses_dirty_ = true;
      });
    update_connection_ = event::Events::ConnectWorldUpdateBegin(
      std::bind(&As3KinematicMirror::OnUpdate, this));
    RCLCPP_INFO(ros_node_->get_logger(),
      "Assem3 kinematic mirror active: /joint_states + /as3/gazebo/kinematic_poses");
  }

 private:
  static ignition::math::Pose3d ToPose(const geometry_msgs::msg::Pose &m) {
    return ignition::math::Pose3d(
      ignition::math::Vector3d(m.position.x, m.position.y, m.position.z),
      ignition::math::Quaterniond(m.orientation.w, m.orientation.x,
                                   m.orientation.y, m.orientation.z));
  }
  void OnUpdate() {
    std::map<std::string, double> joints;
    std::vector<geometry_msgs::msg::Pose> poses;
    bool write_joints = false, write_poses = false;
    {
      std::lock_guard<std::mutex> lk(mutex_);
      if (joints_dirty_) {
        joints = joint_positions_;
        joints_dirty_ = false;
        write_joints = true;
      }
      if (poses_dirty_) {
        poses = poses_;
        poses_dirty_ = false;
        write_poses = true;
      }
    }
    if (write_poses) {
      model_->SetWorldPose(ToPose(poses[0]));
    }
    if (write_joints && !joints.empty()) {
      // Position-only, direct-kinematics (not a torque controller).
      model_->SetJointPositions(joints);
    }
    if (write_poses) {
      for (size_t i = 0; i < sarrus_links_.size() && i+1 < poses.size(); ++i) {
        if (sarrus_links_[i]) sarrus_links_[i]->SetWorldPose(ToPose(poses[i+1]));
      }
    }
  }

  physics::ModelPtr model_;
  gazebo_ros::Node::SharedPtr ros_node_;
  event::ConnectionPtr update_connection_;
  rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr js_sub_;
  rclcpp::Subscription<geometry_msgs::msg::PoseArray>::SharedPtr poses_sub_;
  std::mutex mutex_;
  bool joints_dirty_ = false;
  bool poses_dirty_ = false;
  std::map<std::string, double> joint_positions_;
  std::vector<geometry_msgs::msg::Pose> poses_;
  std::vector<physics::LinkPtr> sarrus_links_;
};
GZ_REGISTER_MODEL_PLUGIN(As3KinematicMirror)
}  // namespace gazebo
