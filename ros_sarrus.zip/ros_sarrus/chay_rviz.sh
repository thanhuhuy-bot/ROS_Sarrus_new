#!/usr/bin/env bash
set -e
source /opt/ros/humble/setup.bash
cd "$(dirname "$(realpath "$0")")"
colcon build --packages-select as3_description --symlink-install
source install/setup.bash
ros2 launch as3_description view_assem3.launch.py "$@"
