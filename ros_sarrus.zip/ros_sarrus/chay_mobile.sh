#!/bin/bash
set -e
cd "$HOME/ros_sarrus"
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch as3_description view_mobile_control.launch.py
