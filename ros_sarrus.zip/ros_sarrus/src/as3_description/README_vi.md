# Assem3 → ROS 2 Humble (BẢN HIỂN THỊ)

Nguồn: `new_design.zip` → `new_design/Assem3.SLDASM` cùng những file `.SLDPRT` đi kèm.
**Không** sử dụng Assem1/2/4.

## Nội dung đã chuyển đổi

- Đọc cây lắp ráp và ma trận vị trí của **Assem3** (SolidWorks `swXmlContents/COMPINSTANCETREE`).
- Trích xuất lưới tam giác hiển thị lưu trong các file SLDPRT gốc (không dùng hình khối thay thế).
- Chép mesh STL theo hệ tọa độ gốc và gán vị trí/hướng đúng theo ma trận assembly.
- Có 2 bản URDF: `assem3_solidworks.urdf` (tọa độ gốc SolidWorks) và `assem3_ros_zup.urdf` (xoay toàn mô hình 90 độ quanh X để tham khảo).
- Các chi tiết bị suppressed trong SolidWorks được giữ ở trạng thái ẩn.

## Cài đặt trong ROS 2 Humble

Giải nén ZIP này vào thư mục Downloads, sau đó:

```bash
mkdir -p ~/ros2_ws/src
cp -r /duong/dan/Assem3_ROS2_Humble/as3_description ~/ros2_ws/src/
cd ~/ros2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select as3_description --symlink-install
source install/setup.bash
ros2 launch as3_description view_assem3.launch.py
```

Chế độ xoay tùy chọn:

```bash
ros2 launch as3_description view_assem3.launch.py z_up:=true
```

Nếu RViz2 hiện `No transform from ...` hoặc `Could not load resource`, kiểm tra đã `source install/setup.bash` và `Fixed Frame = world`; thử `ros2 topic echo /robot_description --once`.

## GIỚI HẠN QUAN TRỌNG

1. **Đây là URDF hiển thị cấu hình lắp ráp đang lưu trong Assem3, KHÔNG PHẢI mô hình điều khiển chuyển động đã hoàn thiện**. Mọi khớp hiện là **fixed** để tái hiện vị trí các chi tiết mà không đoán trục chuyển động, không phải 4 DOF + Sarrus điều khiển được.
2. Các liên kết Sarrus là một **cơ cấu vòng kín**. URDF dạng cây không mô tả đầy đủ ràng buộc cơ khí. Để mô phỏng nâng hạ, cần một khớp tịnh tiến tương đương hoặc mô hình SDF với ràng buộc khớp thích hợp.
3. Chưa có mô-men quán tính, khối lượng, collision mesh và bộ điều khiển. Không sử dụng trực tiếp file này để khẳng định mô phỏng vật lý Gazebo thành công.
4. Mesh được trích xuất từ `Contents/DisplayLists` có sẵn trong file, nên là **lưới hiển thị (display tessellation)**, không phải bề mặt CAD chính xác tuyệt đối. Một số chi tiết trong bộ ZIP có thể khác revision với bản lắp ráp; cần kiểm tra trực quan trong RViz2 trước khi mô phỏng chuyển động.
5. Chưa có ROS 2 runtime trong môi trường tạo file, nên gói đã được kiểm tra về cú pháp/XML và tham chiếu mesh chứ chưa chạy `ros2 launch` thực tế.

## Bước sau (nếu muốn điều khiển)

Cần chỉ ra tên các khâu cố định/khâu di động và các trục khớp trên mô hình Assem3 hoặc xuất bằng SolidWorks SW2URDF. Khi đó có thể xây `robot_state_publisher`, joint state GUI, và nếu cần ROS 2 controllers / Gazebo cho phiên bản động.
