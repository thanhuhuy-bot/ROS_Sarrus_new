ASSEM 3 -> ROS 2 HUMBLE: BẢN CÓ KHỚP (RVIZ2)
===========================================

Bản này thêm cho Assem3:
  - joint_1_sarrus: khớp tịnh tiến đại diện chiều cao Sarrus (0..45 mm) [GIẢ ĐỊNH ĐỂ XEM]
  - joint_2_yaw: quay đế tay máy quanh Z
  - joint_3_shoulder, joint_4_elbow, joint_5_wrist: quay quanh Y
  - left_wheel_joint, right_wheel_joint: quay bánh xe (chỉ trực quan)
  - mobile_x, mobile_y, mobile_yaw: dịch chuyển và xoay đế toàn robot (chỉ trực quan)
  - tcp: hệ tọa độ đầu công tác để xem qua /tf

CÀI GÓI CẦN THIẾT:
  sudo apt update
  sudo apt install ros-humble-joint-state-publisher-gui ros-humble-robot-state-publisher ros-humble-rviz2

NẾU CHƯA CÓ WORKSPACE: giải nén ros_sarrus_v2.zip vào ~/.
Nếu đã có ~/ros_sarrus, sao lưu trước rồi giải nén GHI ĐÈ PACKAGE as3_description.

CHẠY ĐIỀU KHIỂN BẰNG THANH TRƯỢT:
  cd ~/ros_sarrus
  source /opt/ros/humble/setup.bash
  colcon build --packages-select as3_description --symlink-install
  source install/setup.bash
  ros2 launch as3_description view_movable.launch.py

HOẶC CHẠY DEMO TỰ ĐỘNG:
  ros2 launch as3_description view_movable.launch.py demo:=true

GIỮ LẠI BẢN CŨ CHỈ ĐỂ XEM:
  ros2 launch as3_description view_assem3.launch.py

THỰC TẾ KỸ THUẬT, PHẢI ĐỌC:
- Đây là preview động học trên RViz2, KHÔNG phải Gazebo physics hay mô hình điều khiển động lực học.
- Gốc tọa độ/trục và giới hạn khớp tay máy được ƯỚC LƯỢNG từ mesh CAD của Assem3 và cần xác nhận bằng vị trí tâm trục SolidWorks/đo thực tế.
- Sarrus trong URDF là 1 khớp tịnh tiến TƯƠNG ĐƯƠNG, chưa có ràng buộc vòng kín; các thanh nối Sarrus giữ tư thế CAD ban đầu. Khi nâng lên, thanh nối sẽ không chuyển động theo bàn nâng, có thể nhìn thấy khe hở. KHÔNG dùng bản này để kiểm chứng Sarrus vật lý.
- Mô hình CAD ở tư thế lưu sẵn được bảo toàn khi mọi khớp = 0; root được nâng 110 mm để đáy bánh xe nằm trên lưới RViz.
- Chưa có thông số động lực học (khối lượng, quán tính, ma sát), collision hay ros2_control controllers.
- Không lấy chiều dài khâu hoặc tọa độ TCP ở đây làm số liệu chính xác để dùng EKF; cần hiệu chuẩn mô hình với D-H và CAD mate thực.
- Không khởi chạy chay_khop.sh và chay_demo.sh cùng lúc vì sẽ có hai publisher /joint_states.


V3: Bo sung MarkerArray dong cho 8 thanh Sarrus; xem HUONG_DAN_SARRUS_NHIN_LIEN_MACH_V3.txt trong workspace.
