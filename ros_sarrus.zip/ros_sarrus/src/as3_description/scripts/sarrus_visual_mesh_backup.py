#!/usr/bin/env python3
"""RViz-only Sarrus mesh visualization.

Moves original SolidWorks leg meshes to create an approximately connected
folding Sarrus visualization as joint_1_sarrus slides. This does not impose
physical/closed-chain constraints and is NOT a valid mechanical solver.
"""
import json
import math
from pathlib import Path

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from visualization_msgs.msg import Marker, MarkerArray
from ament_index_python.packages import get_package_share_directory


def normalize(v):
    n=math.sqrt(sum(x*x for x in v))
    return [x/n for x in v]


def dot(a,b):
    return sum(x*y for x,y in zip(a,b))


def add(a,b):
    return [x+y for x,y in zip(a,b)]


def mul(a,k):
    return [x*k for x in a]


def sub(a,b):
    return [x-y for x,y in zip(a,b)]


def qmul(a,b):
    ax,ay,az,aw=a;bx,by,bz,bw=b
    return [aw*bx+ax*bw+ay*bz-az*by,
            aw*by-ax*bz+ay*bw+az*bx,
            aw*bz+ax*by-ay*bx+az*bw,
            aw*bw-ax*bx-ay*by-az*bz]


def qrotate(q,v):
    qv=[v[0],v[1],v[2],0.0]
    qi=[-q[0],-q[1],-q[2],q[3]]
    return qmul(qmul(q,qv),qi)[:3]


def q_from_to(a,b):
    a=normalize(a);b=normalize(b)
    c=[a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
    w=1+dot(a,b)
    if w<1e-8:
        other=[1,0,0] if abs(a[0])<0.9 else [0,1,0]
        c=[a[1]*other[2]-a[2]*other[1],a[2]*other[0]-a[0]*other[2],a[0]*other[1]-a[1]*other[0]]
        w=0.0
    return normalize(c+[w])


def set_xyz(msg, v):
    msg.x,msg.y,msg.z=v


def set_xyzw(msg,q):
    msg.x,msg.y,msg.z,msg.w=q


class VirtualSarrus(Node):
    def __init__(self):
        super().__init__('as3_virtual_sarrus')
        p=Path(get_package_share_directory('as3_description'))/'config/sarrus_visual_parts.json'
        self.parts=json.loads(p.read_text(encoding='utf-8'))['parts']
        self.q=0.0
        self.pub=self.create_publisher(MarkerArray,'as3_sarrus/visual_links',10)
        self.sub=self.create_subscription(JointState,'joint_states',self.receive_joint_state,10)
        self.timer=self.create_timer(0.06,self.publish)
        self.get_logger().info('Sarrus virtual CAD links active: joint_1_sarrus = 0..0.045 m')

    def receive_joint_state(self,msg):
        if 'joint_1_sarrus' in msg.name:
            i=msg.name.index('joint_1_sarrus')
            if i<len(msg.position):
                self.q=min(0.045,max(0.0,float(msg.position[i])))

    def _ball(self,mid,pos,diameter,rgba,now):
        m=Marker()
        m.header.frame_id='base_link';m.header.stamp=now
        m.ns='sarrus_virtual_hinges';m.id=mid
        m.type=Marker.SPHERE;m.action=Marker.ADD
        set_xyz(m.pose.position,pos)
        m.pose.orientation.w=1.0
        m.scale.x=m.scale.y=m.scale.z=diameter
        m.color.r,m.color.g,m.color.b,m.color.a=rgba
        m.frame_locked=False
        return m

    def _bar(self,side,direction,part,outer,hinge,now,mid):
        m=Marker()
        m.header.frame_id='base_link';m.header.stamp=now
        m.ns='sarrus_virtual_cad';m.id=mid
        m.type=Marker.MESH_RESOURCE;m.action=Marker.ADD
        m.mesh_resource='package://as3_description/meshes/'+part['mesh']
        m.mesh_use_embedded_materials=False
        v=sub(hinge,outer)
        length=math.sqrt(dot(v,v))
        q0=part['quat']
        u0=qrotate(q0,[1.0,0.0,0.0])
        dq=q_from_to(u0,v)
        qnew=normalize(qmul(dq,q0))
        # The CAD mesh's local X is the long axis, negative X is the outer pivot.
        # Scaling longitudinally produces a harmless cosmetic telescoping effect.
        scale=length/(part['x_max']-part['x_min'])
        m.scale.x=scale;m.scale.y=1.0;m.scale.z=1.0
        origin=sub(outer,qrotate(qnew,[scale*part['x_min'],0.0,0.0]))
        set_xyz(m.pose.position,origin)
        set_xyzw(m.pose.orientation,qnew)
        if direction=='lower':
            m.color.r,m.color.g,m.color.b,m.color.a=(0.09,0.28,0.58,1.0)
        else:
            m.color.r,m.color.g,m.color.b,m.color.a=(0.94,0.48,0.11,1.0)
        return m

    def publish(self):
        messages=MarkerArray()
        now=self.get_clock().now().to_msg()
        for i,side in enumerate(('south','east','north','west')):
            lower=self.parts[side]['lower'];upper=self.parts[side]['upper']
            axis_lower=qrotate(lower['quat'],[1.0,0.0,0.0]);axis_upper=qrotate(upper['quat'],[1.0,0.0,0.0])
            lower_out=add(lower['p'],mul(axis_lower,lower['x_min']))
            upper_out=add(upper['p'],mul(axis_upper,upper['x_min']))
            upper_out[2]+=self.q
            bottom_inner=add(lower['p'],mul(axis_lower,lower['x_max']))
            top_inner=add(upper['p'],mul(axis_upper,upper['x_max']))
            h0=mul(add(bottom_inner,top_inner),.5)
            # Hinge goes up by half the lift and folds in toward the outer pivots.
            horizontal=normalize([axis_lower[0],axis_lower[1],0.0])
            h=add(h0,add([0.0,0.0,self.q/2.0],mul(horizontal,-0.30*self.q)))
            messages.markers.append(self._bar(side,'lower',lower,lower_out,h,now,i*4))
            messages.markers.append(self._bar(side,'upper',upper,upper_out,h,now,i*4+1))
            messages.markers.append(self._ball(i*3,h,0.014,(0.90,0.55,0.12,1.0),now))
            messages.markers.append(self._ball(i*3+1,lower_out,0.011,(0.10,0.29,0.60,1.0),now))
            messages.markers.append(self._ball(i*3+2,upper_out,0.011,(0.90,0.51,0.16,1.0),now))
        self.pub.publish(messages)


def main(args=None):
    rclpy.init(args=args)
    node=VirtualSarrus()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__=='__main__':
    main()
