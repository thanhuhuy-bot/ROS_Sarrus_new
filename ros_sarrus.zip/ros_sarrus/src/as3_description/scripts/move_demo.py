#!/usr/bin/env python3
"""Kinematic preview only: publish example JointState to RViz; not a controller."""
import math
import time
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class ExampleMotion(Node):
    def __init__(self):
        super().__init__('as3_preview_motion')
        self.pub = self.create_publisher(JointState, 'joint_states', 10)
        self.start = time.monotonic()
        self.timer = self.create_timer(0.05, self.update)
        self.names = ['left_wheel_joint', 'right_wheel_joint',
                      'joint_1_sarrus', 'joint_2_yaw', 'joint_3_shoulder',
                      'joint_4_elbow', 'joint_5_wrist']

    def update(self):
        t = time.monotonic() - self.start
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = self.names
        msg.position = [
            0.8 * t, 0.8 * t,            # example wheel rotations
            0.0225 * (1 - math.cos(0.20 * t)),  # Sarrus equivalent lift [0, 0.045]
            0.36 * math.sin(0.16 * t),
            0.38 * math.sin(0.21 * t),
            -0.45 * math.sin(0.21 * t),
            0.20 * math.sin(0.24 * t),
        ]
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = ExampleMotion()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
