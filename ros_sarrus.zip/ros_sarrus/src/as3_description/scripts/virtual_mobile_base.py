#!/usr/bin/env python3
"""RViz-only base with ONE atomic /tf broadcast for every moving joint.

The robot_state_publisher node is remapped off /joint_states and only publishes
fixed TF and /robot_description. All 7 dynamic joints, plus world->base_link,
are instead generated from the exact original Assem3 URDF by this node.
Original CAD meshes, joint axes, geometry and Sarrus visualizer are unchanged.
"""
import math
import time
from pathlib import Path
import xml.etree.ElementTree as ET
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TransformStamped
from std_msgs.msg import Empty
from sensor_msgs.msg import JointState
from tf2_ros import TransformBroadcaster
from ament_index_python.packages import get_package_share_directory


def xyz(text, default):
    return tuple(float(x) for x in (text or default).split())


def normalize(q):
    norm = math.sqrt(sum(a*a for a in q))
    return tuple(a/norm for a in q)


def quaternion_multiply(a,b):
    x,y,z,w=a; X,Y,Z,W=b
    return (w*X+x*W+y*Z-z*Y,
            w*Y-x*Z+y*W+z*X,
            w*Z+x*Y-y*X+z*W,
            w*W-x*X-y*Y-z*Z)


def rotate(q,v):
    x,y,z,w=q
    # R(q) @ v; no extra ROS dependencies
    tx=2*(y*v[2]-z*v[1]);ty=2*(z*v[0]-x*v[2]);tz=2*(x*v[1]-y*v[0])
    return (v[0]+w*tx+(y*tz-z*ty),
            v[1]+w*ty+(z*tx-x*tz),
            v[2]+w*tz+(x*ty-y*tx))


def rpy_quaternion(r,p,y):
    cr,sr=math.cos(r/2),math.sin(r/2)
    cp,sp=math.cos(p/2),math.sin(p/2)
    cy,sy=math.cos(y/2),math.sin(y/2)
    return normalize((sr*cp*cy-cr*sp*sy,
                      cr*sp*cy+sr*cp*sy,
                      cr*cp*sy-sr*sp*cy,
                      cr*cp*cy+sr*sp*sy))


def moving_joint_specs():
    p=Path(get_package_share_directory('as3_description'))/'urdf/as3_movable.urdf'
    root=ET.parse(p).getroot()
    joints=[]
    for j in root.findall('joint'):
        typ=j.get('type')
        if typ not in ('prismatic','revolute','continuous'):
            continue
        origin=j.find('origin');axis_el=j.find('axis')
        orig=xyz(origin.get('xyz') if origin is not None else None,'0 0 0')
        rpy=xyz(origin.get('rpy') if origin is not None else None,'0 0 0')
        ax=xyz(axis_el.get('xyz') if axis_el is not None else None,'1 0 0')
        n=math.sqrt(sum(k*k for k in ax))
        assert n>0
        joints.append((j.get('name'),typ,j.find('parent').get('link'),
                       j.find('child').get('link'),orig,rpy_quaternion(*rpy),
                       tuple(k/n for k in ax)))
    return joints


def dynamic_transform(spec,value,stamp):
    name,typ,parent,child,orig,oq,ax=spec
    tf=TransformStamped()
    tf.header.stamp=stamp;tf.header.frame_id=parent;tf.child_frame_id=child
    if typ=='prismatic':
        shift=rotate(oq,tuple(value*a for a in ax))
        pos=tuple(orig[i]+shift[i] for i in range(3))
        quat=oq
    else:
        dq=tuple(a*math.sin(value/2) for a in ax)+(math.cos(value/2),)
        pos=orig
        quat=normalize(quaternion_multiply(oq,dq))
    tf.transform.translation.x,tf.transform.translation.y,tf.transform.translation.z=pos
    tf.transform.rotation.x,tf.transform.rotation.y,tf.transform.rotation.z,tf.transform.rotation.w=quat
    return tf


class VirtualMobileBase(Node):
    def __init__(self):
        super().__init__('as3_virtual_mobile_base')
        self.declare_parameter('wheel_radius_m',0.04)
        self.declare_parameter('wheel_separation_m',0.32)
        self.declare_parameter('cmd_timeout_s',0.4)
        self.declare_parameter('base_z_m',0.11)
        self.radius=float(self.get_parameter('wheel_radius_m').value)
        self.track=float(self.get_parameter('wheel_separation_m').value)
        self.timeout=float(self.get_parameter('cmd_timeout_s').value)
        self.base_z=float(self.get_parameter('base_z_m').value)
        if self.radius<=0 or self.track<=0:
            raise ValueError('Wheel radius / track must be positive')
        self.x=self.y=self.yaw=0.0
        self.left=self.right=0.0
        self.v=self.w=0.0
        self.last_cmd=-1e12
        self.last_step=time.monotonic()
        self.arm_names=['joint_1_sarrus','joint_2_yaw',
                        'joint_3_shoulder','joint_4_elbow','joint_5_wrist']
        self.arm={name:0.0 for name in self.arm_names}
        self.manual_arm=dict(self.arm)
        self.auto_arm=False
        self.specs=moving_joint_specs()
        self.tf_pub=TransformBroadcaster(self)
        self.js_pub=self.create_publisher(JointState,'/joint_states',10)
        self.create_subscription(JointState,'/arm_joint_states',self.on_arm,10)
        # TCP requests change only joint setpoints, NEVER publish TF.
        # This preserves V4.7's one-owner, one-timestamp TF architecture.
        self.create_subscription(JointState,'/as3/ik_joint_command',self.on_ik_command,10)
        self.create_subscription(Empty,'/as3/tcp_manual',self.on_manual_release,10)
        self.create_subscription(Twist,'/cmd_vel',self.on_cmd,10)
        self.create_timer(1.0/30.0,self.step)
        self.get_logger().info('V4.7: ONE atomic TF message for base + all 7 movable joints at 30 Hz')
        self.publish()

    def on_arm(self,msg):
        for i,name in enumerate(msg.name):
            if name in self.arm and i<len(msg.position):
                pos=float(msg.position[i])
                if math.isfinite(pos):
                    self.manual_arm[name]=pos
                    if not self.auto_arm:
                        self.arm[name]=pos

    def on_ik_command(self,msg):
        valid=0
        for name,pos in zip(msg.name,msg.position):
            if name in self.arm and math.isfinite(float(pos)):
                self.arm[name]=float(pos)
                valid+=1
        if valid:
            self.auto_arm=True

    def on_manual_release(self,_):
        self.auto_arm=False
        self.arm.update(self.manual_arm)
        self.get_logger().info('TCP automatic mode released; sliders active again')

    def on_cmd(self,msg):
        v,w=float(msg.linear.x),float(msg.angular.z)
        if not math.isfinite(v) or not math.isfinite(w):v=w=0.0
        self.v=max(-1,min(1,v));self.w=max(-2,min(2,w))
        self.last_cmd=time.monotonic()

    def step(self):
        now=time.monotonic()
        dt=min(0.10,max(0.0,now-self.last_step))
        self.last_step=now
        v,w=(self.v,self.w) if now-self.last_cmd<self.timeout else (0.0,0.0)
        mid=self.yaw+0.5*w*dt
        self.x+=v*dt*math.cos(mid);self.y+=v*dt*math.sin(mid)
        self.yaw=math.atan2(math.sin(self.yaw+w*dt),math.cos(self.yaw+w*dt))
        self.left+=(v-0.5*self.track*w)/self.radius*dt
        self.right+=(v+0.5*self.track*w)/self.radius*dt
        self.publish()

    def publish(self):
        stamp=self.get_clock().now().to_msg()
        base=TransformStamped()
        base.header.stamp=stamp;base.header.frame_id='world';base.child_frame_id='base_link'
        base.transform.translation.x=self.x;base.transform.translation.y=self.y
        base.transform.translation.z=self.base_z
        base.transform.rotation.z=math.sin(self.yaw/2)
        base.transform.rotation.w=math.cos(self.yaw/2)
        pos=dict(self.arm)
        pos['left_wheel_joint']=self.left
        pos['right_wheel_joint']=self.right
        transforms=[base]+[dynamic_transform(spec,pos.get(spec[0],0.0),stamp) for spec in self.specs]
        # One message + stamp for the complete moving TF tree.
        self.tf_pub.sendTransform(transforms)
        msg=JointState()
        msg.header.stamp=stamp
        msg.name=self.arm_names+['left_wheel_joint','right_wheel_joint']
        msg.position=[pos[n] for n in msg.name]
        self.js_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node=VirtualMobileBase()
    try:rclpy.spin(node)
    except KeyboardInterrupt:pass
    finally:
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()


if __name__=='__main__':
    main()
