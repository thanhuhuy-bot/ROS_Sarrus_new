#!/usr/bin/env python3
"""V4.8.6: Four-dimensional TCP target (X, Y, Z, theta) with Moore-Penrose IK.

The stable V4.7 virtual_mobile_base remains the *only* dynamic TF owner.
The GUI directly subscribes to /joint_states, computes model-based IK and
publishes /as3/ik_joint_command. There is no middleman TCP controller node.
"""
import bisect
import csv
import math
import time
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from tkinter import ttk

import rclpy
from rclpy.node import Node
from ament_index_python.packages import get_package_share_directory
from geometry_msgs.msg import Point, PointStamped, Twist
from sensor_msgs.msg import JointState
from std_msgs.msg import Empty, Float64MultiArray, String
from visualization_msgs.msg import Marker, MarkerArray
from as3_kinematics import ARM_NAMES, RobotKinematics


class TargetGUI(Node):
    def __init__(self):
        super().__init__('as3_tcp_target_gui')
        path=Path(get_package_share_directory('as3_description'))/'urdf/as3_movable.urdf'
        self.kin=RobotKinematics(path)
        self.current={n: 0.0 for n in ARM_NAMES}
        self.have_joint_state=False
        self.last_joint_time=-1e9
        self.base_moving=False
        self.trajectory=None
        self.pending=None
        self.job=None
        self.ik_pool=ThreadPoolExecutor(max_workers=1)
        self.goal=None
        self.trail=[]
        self.started=0.0
        self.duration=0.0
        self.last_publish=0.0
        self.log_path=Path.home()/'.ros/as3_tcp_trials_xyzt.csv'
        self.closing=False
        self.cmd_pub=self.create_publisher(JointState,'/as3/ik_joint_command',10)
        self.manual_pub=self.create_publisher(Empty,'/as3/tcp_manual',10)
        self.marker_pub=self.create_publisher(MarkerArray,'/as3/tcp_markers',10)
        self.xyz_pub=self.create_publisher(PointStamped,'/as3/tcp_current',10)
        self.status_pub=self.create_publisher(String,'/as3/tcp_status',10)
        self.create_subscription(JointState,'/joint_states',self.on_joint,10)
        self.create_subscription(Twist,'/cmd_vel',self.on_base_cmd,10)
        self.create_subscription(Float64MultiArray,'/as3/tcp_goal',self.on_external_goal,10)
        self.create_subscription(Empty,'/as3/tcp_stop',lambda _:self.stop(),10)
        self.root=tk.Tk()
        self.root.title('Assem3 - TCP XYZ + Theta | Jacobian IK V4.8.6')
        self.root.resizable(False,False)
        self.root.configure(padx=12,pady=10)
        ttk.Label(self.root,text='ĐIỀU KHIỂN TCP THEO TỌA ĐỘ',font=('TkDefaultFont',11,'bold')).grid(row=0,column=0,columnspan=3,pady=(0,8))
        ttk.Label(self.root,text='Hệ tọa độ: base_link   |   Đơn vị: mét').grid(row=1,column=0,columnspan=3,sticky='w')
        self.vars={}
        for i,(name,default) in enumerate((('X','0.400'),('Y','0.055'),('Z','0.230')),start=2):
            ttk.Label(self.root,text=f'{name} (m):').grid(row=i,column=0,sticky='w',pady=3)
            var=tk.StringVar(value=default)
            ttk.Entry(self.root,width=14,textvariable=var).grid(row=i,column=1,sticky='w',padx=5)
            self.vars[name]=var
        self.allow=tk.BooleanVar(value=False)
        ttk.Checkbutton(self.root,text='Cho phép Sarrus nâng hạ khi giải IK',variable=self.allow).grid(row=5,column=0,columnspan=3,sticky='w',pady=6)
        ttk.Label(self.root,text='θ (độ):').grid(row=6,column=0,sticky='w',pady=3)
        self.theta_var=tk.StringVar(value='0.0')
        ttk.Entry(self.root,width=14,textvariable=self.theta_var).grid(row=6,column=1,sticky='w',padx=5)
        ttk.Label(self.root,text='θ = q3 + q4 + q5  ·  Jacobian 4 hàng (X,Y,Z,θ)').grid(row=7,column=0,columnspan=3,sticky='w',pady=(1,5))
        ttk.Button(self.root,text='Lấy tọa độ TCP hiện tại',command=self.use_current).grid(row=8,column=0,columnspan=3,sticky='ew',pady=3)
        ttk.Button(self.root,text='▶ ĐẾN TỌA ĐỘ MỤC TIÊU',command=self.go).grid(row=9,column=0,columnspan=3,sticky='ew',pady=4)
        ttk.Button(self.root,text='■ DỪNG / GIỮ TƯ THẾ',command=self.stop).grid(row=10,column=0,columnspan=3,sticky='ew',pady=2)
        ttk.Button(self.root,text='Trả quyền cho thanh trượt (MANUAL)',command=self.manual).grid(row=11,column=0,columnspan=3,sticky='ew',pady=2)
        self.xyz_text=tk.StringVar(value='TCP hiện tại: đang nhận /joint_states...')
        ttk.Label(self.root,textvariable=self.xyz_text).grid(row=12,column=0,columnspan=3,sticky='w',pady=(10,3))
        self.state_text=tk.StringVar(value='Chờ trạng thái khớp từ Mobile Base...')
        ttk.Label(self.root,textvariable=self.state_text,wraplength=380,justify='left').grid(row=13,column=0,columnspan=3,sticky='w')
        ttk.Label(self.root,text='Hệ base_link · IK Jacobian 4×4/4×5 + tránh giới hạn khớp',foreground='#666').grid(row=14,column=0,columnspan=3,sticky='w',pady=(5,0))
        self.root.bind('<Escape>',lambda _:self.stop())
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.last_marker=0.0
        self.root.after(40,self.tick)
        # Give RViz time to appear, then explicitly show this Tk window in front.
        self.root.after(450,self.show_on_top)
        self.get_logger().info('V4.8.6: XYZ + theta=q3+q4+q5, four-row Jacobian IK; V4.7 TF unchanged')

    def status(self,text):
        self.state_text.set(text)
        msg=String();msg.data=text
        self.status_pub.publish(msg)
        self.get_logger().info(text)

    def on_joint(self,msg):
        present=set(msg.name)
        if not all(n in present for n in ARM_NAMES):
            if not self.have_joint_state:
                self.state_text.set('LỖI: /joint_states chưa có đủ 5 khớp Sarrus + tay máy.')
            return
        for n,p in zip(msg.name,msg.position):
            if n in self.current and math.isfinite(float(p)):
                self.current[n]=float(p)
        first_message=not self.have_joint_state
        self.last_joint_time=time.monotonic()
        self.have_joint_state=True
        if first_message:
            self.status('Đã nhận đủ 5 khớp /joint_states. Sẵn sàng giải IK.')
        pt=self.kin.fk(self.current)
        self.xyz_text.set('TCP: X=%.3f Y=%.3f Z=%.3f m | θ=%.2f°'%(*pt,math.degrees(self.kin.theta(self.current))))
        current=PointStamped()
        current.header.frame_id='base_link';current.header.stamp=self.get_clock().now().to_msg()
        current.point.x,current.point.y,current.point.z=pt
        self.xyz_pub.publish(current)

    def on_base_cmd(self,msg):
        moving=(abs(msg.linear.x)>1e-4 or abs(msg.angular.z)>1e-4)
        if moving and not self.base_moving and (self.trajectory is not None or self.pending is not None):
            self.stop()
            self.status('DỪNG TCP: Mobile Base đang chạy. Bấm STOP Base trước.')
        self.base_moving=moving

    def use_current(self):
        if not self.have_joint_state:
            self.status('Chưa nhận /joint_states. Kiểm tra node as3_virtual_mobile_base.');return
        for key,val in zip(('X','Y','Z'),self.kin.fk(self.current)):
            self.vars[key].set('%.4f'%val)
        self.theta_var.set('%.2f'%math.degrees(self.kin.theta(self.current)))
        self.status('Đã lấy tọa độ TCP hiện tại.')

    def go(self):
        try:
            xyz=tuple(float(self.vars[k].get().strip().replace(',','.')) for k in ('X','Y','Z'))
            if not all(math.isfinite(x) for x in xyz):raise ValueError()
        except ValueError:
            self.status('LỖI: tọa độ X, Y, Z phải là số hữu hạn tính bằng mét.');return
        try:
            theta_deg=float(self.theta_var.get().strip().replace(',','.'))
            if not math.isfinite(theta_deg):raise ValueError()
        except ValueError:
            self.status('LỖI: θ phải là số hữu hạn tính bằng độ.');return
        self.request(xyz,self.allow.get(),math.radians(theta_deg))

    def on_external_goal(self,msg):
        # The new API always accepts a 4D target: [X, Y, Z, theta_deg].
        # Optional fifth value is the Sarrus-enable flag (0 or 1).
        if len(msg.data) in (4,5) and all(math.isfinite(x) for x in msg.data):
            allow=bool(msg.data[4]>=0.5) if len(msg.data)==5 else self.allow.get()
            self.request(tuple(msg.data[:3]),allow,math.radians(msg.data[3]))
        else:self.status('LỖI: /as3/tcp_goal cần [X,Y,Z,theta_deg] (+ allow_sarrus tùy chọn).')

    def request(self,xyz,allow_sarrus,theta_target):
        if not self.have_joint_state or time.monotonic()-self.last_joint_time>1.0:
            self.status('CHƯA THỂ CHẠY: không nhận /joint_states từ Mobile Base.');return
        if self.base_moving:
            self.status('CHƯA THỂ CHẠY: bấm STOP trong Base Control trước.');return
        if self.job is not None and not self.job.done():
            self.status('Đang giải IK, không gửi thêm mục tiêu lúc này.');return
        self.trajectory=None
        self.goal=xyz
        # Convert the paper's theta=q3+q4+q5 to the URDF physical pitch.
        # The URDF has a small fixed pitch origin offset (~0.455 degrees).
        pitch_target=theta_target+self.kin.pitch_zero
        seed=dict(self.current)
        self.pending=(xyz,allow_sarrus,seed,pitch_target)
        self.job=self.ik_pool.submit(self.kin.ik_with_path,xyz,seed,allow_sarrus,0.0002,pitch_target)
        nr=5 if allow_sarrus else 4
        self.status('Đang giải IK Jacobian 4x%d cho (X,Y,Z,θ) (Moore-Penrose + null-space)...'%nr)

    def send_pose(self,pose):
        msg=JointState()
        msg.header.stamp=self.get_clock().now().to_msg()
        msg.name=list(ARM_NAMES)
        msg.position=[float(pose[n]) for n in ARM_NAMES]
        self.cmd_pub.publish(msg)

    def handle_ik(self):
        if self.pending is None or self.job is None or not self.job.done():return
        xyz,allow,seed,pitch_target=self.pending
        self.pending=None
        try:
            result,error,path=self.job.result()
        except Exception as exc:
            self.status('LỖI tính IK Jacobian: %s'%exc);return
        if result is None:
            self.trail=[]
            self.log_trial(xyz,allow,None,None,False,error,0,pitch_target)
            self.status('KHÔNG TỚI ĐƯỢC đủ (X,Y,Z,θ): sai số vị trí tốt nhất %.3f mm; yêu cầu ≤0.2 mm và |Δθ|≤0.5°.'%(error*1000))
            return
        # Differential IK generates the complete waypoint path. Playback
        # follows that same path (not the old cubic joint interpolation).
        # Segment durations honor the per-joint visualization speed limits.
        if len(path)<2:
            path=[dict(seed),dict(result)]
        times=[0.0]
        for a,b in zip(path,path[1:]):
            ds=abs(b['joint_1_sarrus']-a['joint_1_sarrus'])/0.035
            da=max(abs(b[n]-a[n])/0.65 for n in ARM_NAMES[1:])
            times.append(times[-1]+max(0.025,ds,da))
        self.duration=max(0.05,times[-1])
        self.started=time.monotonic()
        self.trajectory=(path,times,xyz,allow,error,pitch_target)
        step=max(1,len(path)//180)
        self.trail=[self.kin.fk(q) for q in path[::step]]
        if len(self.trail)<1 or self.trail[-1]!=self.kin.fk(path[-1]):
            self.trail.append(self.kin.fk(path[-1]))
        self.status('TÌM THẤY NGHIỆM: sai số %.3f mm, %d bước Jacobian; đang di chuyển (%.1fs).'%(
            error*1000,len(path)-1,self.duration))
        self.send_pose(seed)

    def animate(self):
        if self.trajectory is None:return
        path,times,xyz,allow,error,pitch_target=self.trajectory
        elapsed=min(self.duration,time.monotonic()-self.started)
        i=min(len(path)-2,max(0,bisect.bisect_right(times,elapsed)-1))
        denom=times[i+1]-times[i]
        s=max(0.0,min(1.0,(elapsed-times[i])/denom)) if denom>1e-12 else 1.0
        q={n:path[i][n]+(path[i+1][n]-path[i][n])*s for n in ARM_NAMES}
        self.send_pose(q)
        if elapsed>=self.duration:
            self.trajectory=None
            end=path[-1]
            pt=self.kin.fk(end)
            e=math.dist(pt,xyz)
            self.log_trial(xyz,allow,pt,end,True,e,self.duration,pitch_target)
            status='HOÀN THÀNH: sai số XYZ %.3f mm | sai số θ %.3f° | CSV: ~/.ros/as3_tcp_trials_xyzt.csv'%(e*1000,abs(math.degrees(pitch_target-self.kin.pitch(end))))
            self.status(status)
        elif time.monotonic()-self.last_publish>0.7:
            self.last_publish=time.monotonic()
            self.status('TCP đang chạy theo Jacobian: %d%%'%(100*elapsed/self.duration))

    def stop(self):
        self.pending=None
        self.trajectory=None
        if self.have_joint_state:
            self.send_pose(dict(self.current))
        self.status('DỪNG TCP: giữ tư thế. Bấm MANUAL để dùng thanh trượt.')

    def manual(self):
        self.pending=None
        self.trajectory=None
        self.goal=None
        self.trail=[]
        self.manual_pub.publish(Empty())
        self.status('Đã trả điều khiển cho thanh trượt (robot có thể về vị trí của slider).')

    def log_trial(self,xyz,allow,actual,joints,success,error,duration,pitch_target=None):
        try:
            self.log_path.parent.mkdir(parents=True,exist_ok=True)
            fresh=not self.log_path.exists() or self.log_path.stat().st_size==0
            with self.log_path.open('a',encoding='utf-8',newline='') as fp:
                writer=csv.writer(fp)
                if fresh:
                    writer.writerow(['timestamp','method','success','target_x_m','target_y_m','target_z_m',
                                     'fk_x_m','fk_y_m','fk_z_m','fk_error_mm',
                                     'best_ik_residual_mm','allow_sarrus','motion_duration_s',
                                     'theta_target_deg','theta_fk_deg','theta_error_deg']+list(ARM_NAMES))
                theta_actual=math.degrees(self.kin.theta(joints)) if joints else None
                writer.writerow([datetime.now().isoformat(timespec='seconds'),'Jacobian-MoorePenrose-nullspace',int(success),
                                 *[round(x,6) for x in xyz],
                                 *([round(x,6) for x in actual] if actual is not None else ['', '', '']),
                                 round(error*1000,3) if success else '',
                                 round(error*1000,3),int(allow),round(duration,3),
                                 round(math.degrees(pitch_target-self.kin.pitch_zero),3),
                                 '' if theta_actual is None else round(theta_actual,3),
                                 '' if theta_actual is None else round(abs(math.degrees(pitch_target-self.kin.pitch_zero)-theta_actual),3),
                                 *([round(joints[n],6) for n in ARM_NAMES] if joints else ['']*len(ARM_NAMES))])
        except OSError as exc:
            self.get_logger().warning('CSV log failed: %s'%exc)

    @staticmethod
    def marker(ns,idx,kind,rgba,xyz,scale):
        m=Marker();m.header.frame_id='base_link'
        m.header.stamp.sec=0;m.header.stamp.nanosec=0
        m.ns=ns;m.id=idx;m.action=Marker.ADD;m.type=kind;m.frame_locked=True
        m.pose.orientation.w=1.0
        # rclpy generated ROS messages require Python float for float32/float64
        # fields (even e.g. alpha=1 or position=(0,0,0) must be 1.0/0.0).
        m.pose.position.x,m.pose.position.y,m.pose.position.z=(float(v) for v in xyz)
        m.scale.x,m.scale.y,m.scale.z=(float(v) for v in scale)
        m.color.r,m.color.g,m.color.b,m.color.a=(float(v) for v in rgba)
        return m

    def publish_markers(self):
        a=MarkerArray()
        current_pt=self.kin.fk(self.current)
        a.markers.append(self.marker('tcp_actual',0,Marker.SPHERE,(.1,.85,.45,1),current_pt,(.016,)*3))
        if self.goal is not None:
            a.markers.append(self.marker('tcp_target',1,Marker.SPHERE,(1,.3,.1,1),self.goal,(.022,)*3))
            link=self.marker('tcp_error',2,Marker.LINE_LIST,(1,.86,.05,.95),(0,0,0),(.003,0,0))
            for pos in (current_pt,self.goal):
                p=Point();p.x,p.y,p.z=pos
                link.points.append(p)
            a.markers.append(link)
        if len(self.trail)>1:
            line=self.marker('tcp_planned_path',3,Marker.LINE_STRIP,(0,.65,1,.75),(0,0,0),(.002,0,0))
            for pos in self.trail:
                p=Point();p.x,p.y,p.z=pos
                line.points.append(p)
            a.markers.append(line)
        present={(m.ns,m.id) for m in a.markers}
        for ns,idx in (('tcp_target',1),('tcp_error',2),('tcp_planned_path',3)):
            if (ns,idx) not in present:
                m=Marker();m.header.frame_id='base_link';m.ns=ns;m.id=idx;m.action=Marker.DELETE
                a.markers.append(m)
        self.marker_pub.publish(a)

    def tick(self):
        if self.closing:return
        try:
            # Callbacks must continue spinning even when a visualization
            # update fails; otherwise the GUI falsely reports no joint states.
            for _ in range(4):
                rclpy.spin_once(self,timeout_sec=0.0)
            self.handle_ik()
            self.animate()
            now=time.monotonic()
            if self.have_joint_state and now-self.last_joint_time>2.0:
                self.xyz_text.set('LỖI: mất dữ liệu /joint_states > 2 giây')
            if not self.have_joint_state and now-self.last_publish>3.0:
                self.last_publish=now
                self.status('Chưa nhận /joint_states. Kiểm tra node /as3_virtual_mobile_base.')
            if now-self.last_marker>0.13:
                self.last_marker=now
                self.publish_markers()
        except Exception as exc:
            # Tkinter suppresses exceptions from after() callbacks. Always
            # report failures but keep receiving ROS messages.
            now=time.monotonic()
            if now-getattr(self,'last_tick_error',-1e9)>3.0:
                self.last_tick_error=now
                self.get_logger().error('TCP GUI update failed: %s: %s'%(type(exc).__name__,exc))
        finally:
            if not self.closing:
                try:
                    self.root.after(34,self.tick)
                except tk.TclError:
                    pass

    def show_on_top(self):
        """Present the TCP panel above RViz, then relinquish always-on-top."""
        if self.closing:
            return
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.attributes('-topmost', True)
            self.root.focus_force()
            self.root.after(1800, self.release_topmost)
            self.get_logger().info('TCP GUI window shown and brought to front.')
        except tk.TclError as exc:
            self.get_logger().warning('Cannot raise TCP GUI window: %s' % exc)

    def release_topmost(self):
        if self.closing:
            return
        try:
            self.root.attributes('-topmost', False)
        except tk.TclError:
            pass

    def close(self):
        if self.closing:return
        self.closing=True
        self.pending=None;self.trajectory=None
        self.ik_pool.shutdown(wait=False,cancel_futures=True)
        self.root.destroy()


def main(args=None):
    rclpy.init(args=args)
    node=TargetGUI()
    try:node.root.mainloop()
    except KeyboardInterrupt:pass
    finally:
        if not node.closing:node.close()
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()

if __name__=='__main__':main()
