#!/usr/bin/env python3
"""RViz rendering of ONLY the eight ORIGINAL SolidWorks Sarrus bar meshes.

No spheres, bars, resized beams or substitute geometry. Rigid mesh poses
are computed from pivots found in Assem3; this is visualization only, not
Gazebo closed-chain physics. Mobile base's existing TF stays unchanged.
"""
import json
import math
from pathlib import Path
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from visualization_msgs.msg import Marker, MarkerArray
from ament_index_python.packages import get_package_share_directory
from sarrus_rigid_math import link_poses_at, MIN_LIFT, MAX_LIFT


class SarrusCAD(Node):
    def __init__(self):
        super().__init__('as3_sarrus_original_cad')
        cfg=Path(get_package_share_directory('as3_description'))/'config/sarrus_visual_parts.json'
        self.parts=json.loads(cfg.read_text(encoding='utf-8'))['parts']
        self.lift=0.0
        self.pub=self.create_publisher(MarkerArray,'/as3_sarrus/visual_links',10)
        self.sub=self.create_subscription(JointState,'/joint_states',self.on_joint,10)
        self.timer=self.create_timer(.15,self.publish)
        self.get_logger().info('Sarrus: original 8 Assem3 SolidWorks CAD meshes; no substitute geometry or scaling')

    def on_joint(self,msg):
        if 'joint_1_sarrus' not in msg.name:
            return
        i=msg.name.index('joint_1_sarrus')
        if i<len(msg.position) and math.isfinite(float(msg.position[i])):
            self.lift=max(MIN_LIFT,min(MAX_LIFT,float(msg.position[i])))

    def publish(self):
        array=MarkerArray()
        idx=0
        for side in ('south','east','north','west'):
            pair=link_poses_at(self.parts[side],self.lift)
            for which in ('lower','upper'):
                data=pair[which]
                m=Marker()
                m.header.frame_id='base_link'
                m.header.stamp.sec=0
                m.header.stamp.nanosec=0
                m.ns='sarrus_original_solidworks'
                m.id=idx
                idx+=1
                m.type=Marker.MESH_RESOURCE
                m.action=Marker.ADD
                m.frame_locked=True
                m.mesh_resource='package://as3_description/meshes/'+data['mesh']
                m.mesh_use_embedded_materials=False
                m.pose.position.x,m.pose.position.y,m.pose.position.z=data['position']
                m.pose.orientation.x,m.pose.orientation.y,m.pose.orientation.z,m.pose.orientation.w=data['quat']
                m.scale.x=m.scale.y=m.scale.z=1.0
                if which=='lower':
                    m.color.r,m.color.g,m.color.b,m.color.a=(0.16,0.35,0.65,1.0)
                else:
                    m.color.r,m.color.g,m.color.b,m.color.a=(0.78,0.46,0.15,1.0)
                array.markers.append(m)
        self.pub.publish(array)


def main(args=None):
    rclpy.init(args=args)
    node=SarrusCAD()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()

if __name__=='__main__':
    main()
