#!/usr/bin/env python3
"""V4.9 autonomous RViz-only test: world target -> mobile -> Jacobian IK.

The stable V4.7 virtual_mobile_base.py is the ONLY dynamic /tf publisher.
This node only subscribes to that TF and publishes /cmd_vel and joint goals.
No EKF, Gazebo dynamics, mapping, Nav2, grasping or collision planning.
"""
import bisect
import csv
import math
import time
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from tkinter import ttk

import rclpy
from rclpy.node import Node
from ament_index_python.packages import get_package_share_directory
from geometry_msgs.msg import Twist, Point
from sensor_msgs.msg import JointState
from std_msgs.msg import Empty
from tf2_msgs.msg import TFMessage
from visualization_msgs.msg import Marker, MarkerArray
from as3_auto_math import base_to_world, world_to_base, wrap, navigation_step
from as3_kinematics import ARM_NAMES, RobotKinematics


class AutoTask(Node):
    def __init__(self):
        super().__init__('as3_auto_task_gui')
        urdf=Path(get_package_share_directory('as3_description'))/'urdf/as3_movable.urdf'
        self.kin=RobotKinematics(urdf)
        self.current={n:0.0 for n in ARM_NAMES}
        self.base=None  # (x,y,z,yaw) measured directly from /tf
        self.last_tf=-1e10
        self.last_js=-1e10
        self.stage='IDLE'
        self.nav_phase='ALIGN'
        self.goal=None
        self.ik_pool=ThreadPoolExecutor(max_workers=1)  # never use rclpy.Node.executor
        self.ik_future=None
        self.ik_purpose=None
        self.path=[]
        self.times=[]
        self.motion_start=0.0
        self.t_start=0.0
        self.t_nav_end=0.0
        self.t_end=0.0
        self.base_track=[]
        self.last_base_track=0.0
        self.last_status_text=''
        self.last_status_time=0.0
        self.last_marker=0.0
        self.closing=False
        self.error_before=0.0
        self.cmd_pub=self.create_publisher(Twist,'/cmd_vel',10)
        self.joint_pub=self.create_publisher(JointState,'/as3/ik_joint_command',10)
        self.manual_pub=self.create_publisher(Empty,'/as3/tcp_manual',10)
        self.marker_pub=self.create_publisher(MarkerArray,'/as3/auto_markers',10)
        self.create_subscription(TFMessage,'/tf',self.on_tf,20)
        self.create_subscription(JointState,'/joint_states',self.on_joint,10)
        self.file=Path.home()/'.ros/as3_auto_task_trials.csv'
        self.make_ui()
        self.root.after(40,self.tick)
        self.root.after(900,self.show_on_top)
        self.get_logger().info('V4.9 Auto world -> base navigation -> Sarrus/arm Jacobian IK; TF owner V4.7 untouched.')

    def make_ui(self):
        root=self.root=tk.Tk()
        root.title('Assem3 - Phối hợp Mobile + Sarrus + Arm V4.9')
        root.resizable(False,False)
        root.configure(padx=12,pady=10)
        r=0
        ttk.Label(root,text='NHIỆM VỤ TỰ ĐỘNG - TỌA ĐỘ WORLD',font=('TkDefaultFont',11,'bold')).grid(row=r,column=0,columnspan=4,pady=(0,7));r+=1
        ttk.Label(root,text='1. Điểm dừng Mobile Base (world)',font=('TkDefaultFont',10,'bold')).grid(row=r,column=0,columnspan=4,sticky='w',pady=(5,2));r+=1
        self.fields={}
        for j,(name,title,val) in enumerate((('base_x','X (m)','0.150'),('base_y','Y (m)','0.000'),('base_yaw','Yaw (độ)','0.0'))):
            ttk.Label(root,text=title).grid(row=r,column=j,sticky='w')
            var=tk.StringVar(value=val);self.fields[name]=var
            ttk.Entry(root,width=12,textvariable=var).grid(row=r+1,column=j,sticky='w',padx=(0,8))
        r+=2
        ttk.Label(root,text='2. Mục tiêu TCP trong world',font=('TkDefaultFont',10,'bold')).grid(row=r,column=0,columnspan=4,sticky='w',pady=(10,2));r+=1
        for j,(name,title,val) in enumerate((('world_x','X (m)','0.550'),('world_y','Y (m)','0.055'),('world_z','Z (m)','0.340'),('theta','θ (độ)','0.0'))):
            ttk.Label(root,text=title).grid(row=r,column=j,sticky='w')
            var=tk.StringVar(value=val);self.fields[name]=var
            ttk.Entry(root,width=12,textvariable=var).grid(row=r+1,column=j,sticky='w',padx=(0,8))
        r+=2
        self.allow=tk.BooleanVar(value=True)
        ttk.Checkbutton(root,text='Cho phép nâng hạ Sarrus khi giải IK',variable=self.allow).grid(row=r,column=0,columnspan=4,sticky='w',pady=6);r+=1
        ttk.Button(root,text='▶ CHẠY NHIỆM VỤ TỰ ĐỘNG',command=self.start).grid(row=r,column=0,columnspan=4,sticky='ew',pady=(7,4));r+=1
        ttk.Button(root,text='■ DỪNG TOÀN BỘ',command=self.stop).grid(row=r,column=0,columnspan=4,sticky='ew',pady=3);r+=1
        ttk.Button(root,text='Trả quyền tay máy cho các thanh trượt',command=self.manual).grid(row=r,column=0,columnspan=4,sticky='ew',pady=3);r+=1
        self.base_text=tk.StringVar(value='Base: đang nhận world → base_link ...')
        ttk.Label(root,textvariable=self.base_text).grid(row=r,column=0,columnspan=4,sticky='w',pady=(12,2));r+=1
        self.tcp_text=tk.StringVar(value='TCP: đang nhận /joint_states ...')
        ttk.Label(root,textvariable=self.tcp_text).grid(row=r,column=0,columnspan=4,sticky='w');r+=1
        self.status_text=tk.StringVar(value='Chờ dữ liệu TF và /joint_states.')
        ttk.Label(root,textvariable=self.status_text,wraplength=440,justify='left').grid(row=r,column=0,columnspan=4,sticky='w',pady=(10,4));r+=1
        ttk.Label(root,text='Chỉ mô phỏng RViz2; điểm dừng phải ở vùng không có vật cản.',foreground='#666').grid(row=r,column=0,columnspan=4,sticky='w');r+=1
        ttk.Label(root,text='STOP hoặc Esc để dừng. CSV: ~/.ros/as3_auto_task_trials.csv',foreground='#666').grid(row=r,column=0,columnspan=4,sticky='w')
        root.bind('<Escape>',lambda _ :self.stop())
        root.protocol('WM_DELETE_WINDOW',self.close)

    def show_on_top(self):
        if self.closing:return
        try:
            self.root.lift();self.root.attributes('-topmost',True)
            self.root.after(1600,lambda:self.root.attributes('-topmost',False) if not self.closing else None)
        except tk.TclError:pass

    def info(self,text,force=False):
        t=time.monotonic()
        if force or text!=self.last_status_text and t-self.last_status_time>0.40:
            self.status_text.set(text)
            self.last_status_text=text
            self.last_status_time=t
            self.get_logger().info(text)

    def on_tf(self,msg):
        for tf in msg.transforms:
            if tf.header.frame_id.lstrip('/')=='world' and tf.child_frame_id.lstrip('/')=='base_link':
                t=tf.transform.translation
                q=tf.transform.rotation
                yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
                self.base=(float(t.x),float(t.y),float(t.z),float(yaw))
                self.last_tf=time.monotonic()
                break

    def on_joint(self,msg):
        if not all(n in msg.name for n in ARM_NAMES):return
        for n,v in zip(msg.name,msg.position):
            if n in self.current and math.isfinite(v):self.current[n]=float(v)
        self.last_js=time.monotonic()

    def fresh(self):
        now=time.monotonic()
        return self.base is not None and now-self.last_tf<1.0 and now-self.last_js<1.0

    def send_velocity(self,v=0.0,w=0.0):
        msg=Twist();msg.linear.x=float(v);msg.angular.z=float(w)
        self.cmd_pub.publish(msg)

    def send_arm(self,pose):
        msg=JointState()
        msg.header.stamp=self.get_clock().now().to_msg()
        msg.name=list(ARM_NAMES)
        msg.position=[float(pose[n]) for n in ARM_NAMES]
        self.joint_pub.publish(msg)

    def parse(self):
        v={}
        for name,tkvar in self.fields.items():
            n=float(tkvar.get().strip().replace(',','.'))
            if not math.isfinite(n):raise ValueError(name+' không phải số hữu hạn')
            v[name]=n
        if v['world_z']<0:raise ValueError('Z mục tiêu phải không âm')
        if math.hypot(v['base_x'],v['base_y'])>8.0:raise ValueError('Điểm dừng cách world quá 8 m (giới hạn mô phỏng)')
        return {
            'base':(v['base_x'],v['base_y'],math.radians(v['base_yaw'])),
            'world':(v['world_x'],v['world_y'],v['world_z']),
            'theta':math.radians(v['theta']),
            'allow':bool(self.allow.get()),
        }

    def start(self):
        if self.stage not in ('IDLE','DONE','ERROR','STOPPED'):
            self.info('Nhiệm vụ đang chạy. Bấm DỪNG nếu muốn đổi mục tiêu.',True);return
        if self.ik_future is not None and not self.ik_future.done():
            self.info('Bộ giải IK cũ chưa hoàn tất; chưa thể bắt đầu nhiệm vụ mới.',True);return
        if not self.fresh():
            self.info('Chưa nhận đủ /tf (world → base_link) và /joint_states. Không chạy.',True);return
        try:self.goal=self.parse()
        except (ValueError,OverflowError) as exc:
            self.info('Tọa độ không hợp lệ: '+str(exc),True);return
        self.t_start=time.monotonic()
        self.error_before=0.0
        self.base_track=[self.base[:2]]
        self.last_base_track=self.t_start
        self.nav_phase='ALIGN'
        self.stage='CHECK_IK'
        self.send_velocity()
        # Precheck target feasibility at the intended mobile stop. Do not move
        # the base at all for a geometrically impossible final TCP target.
        self.solve_at((self.goal['base'][0],self.goal['base'][1],self.base[2],self.goal['base'][2]),'PRECHECK')
        self.info('Bước 1/3: kiểm tra nghiệm IK tại điểm dừng trước khi di chuyển.',True)

    def solve_at(self,base,reason):
        local=world_to_base(self.goal['world'],base)
        start=dict(self.current)
        # theta = q3+q4+q5; physical tool pitch adds URDF fixed pitch offset.
        pitch=self.goal['theta']+self.kin.pitch_zero
        self.ik_future=self.ik_pool.submit(self.kin.ik_with_path,local,start,self.goal['allow'],0.0002,pitch)
        self.ik_purpose=(reason,local)

    def finish_ik(self):
        if self.ik_future is None or not self.ik_future.done():return
        fut=self.ik_future
        self.ik_future=None
        purpose,local=self.ik_purpose
        try:result,residual,path=fut.result()
        except Exception as exc:
            self.abort('Lỗi bộ giải IK: '+repr(exc));return
        if result is None:
            self.abort('Không tìm được nghiệm đạt XYZ ≤0,2 mm, |Δθ|≤0,5° ('+purpose+'). Sai số tốt nhất %.3f mm.'%(residual*1000));return
        if purpose=='PRECHECK':
            self.stage='DRIVING'
            self.info('Bước 2/3: đã kiểm tra IK, Mobile Base đang tới điểm dừng.',True)
            return
        if purpose!='FINAL':return
        # Follow the exact differential Jacobian IK waypoints from V4.8.6.
        if len(path)<2:path=[dict(self.current),dict(result)]
        self.path=path
        self.times=[0.0]
        for a,b in zip(path,path[1:]):
            ds=abs(b['joint_1_sarrus']-a['joint_1_sarrus'])/0.035
            da=max(abs(b[n]-a[n])/0.65 for n in ARM_NAMES[1:])
            self.times.append(self.times[-1]+max(0.025,ds,da))
        self.motion_start=time.monotonic()
        self.motion_duration=self.times[-1]
        self.stage='ARM_MOVING'
        self.info('Bước 3/3: Mobile dừng; Jacobian IK có nghiệm (%.3f mm); tay máy đang chạy.'%(residual*1000),True)

    def nav_tick(self):
        if self.stage!='DRIVING':return
        now=time.monotonic()
        if now-self.t_start>100:
            self.abort('Quá 100 giây chưa tới điểm dừng. Dừng an toàn.');return
        self.nav_phase,v,w=navigation_step(self.base,self.goal['base'],self.nav_phase)
        self.send_velocity(v,w)
        if now-self.last_base_track>0.12:
            self.last_base_track=now
            self.base_track.append(self.base[:2])
        if self.nav_phase=='DONE':
            self.send_velocity()
            self.t_nav_end=now
            self.stage='FINAL_IK'
            # Recompute using ACTUAL base pose, so a few-mm base stop
            # residual does NOT become TCP world-position error.
            self.solve_at(self.base,'FINAL')
            self.info('Mobile đã dừng, đang giải lại IK với vị trí thực tế của Base.',True)

    def arm_tick(self):
        if self.stage!='ARM_MOVING':return
        elapsed=min(self.motion_duration,time.monotonic()-self.motion_start)
        idx=min(len(self.path)-2,max(0,bisect.bisect_right(self.times,elapsed)-1))
        span=self.times[idx+1]-self.times[idx]
        fraction=max(0.0,min(1.0,(elapsed-self.times[idx])/span)) if span>1e-9 else 1.0
        qa,qb=self.path[idx],self.path[idx+1]
        pos={n:qa[n]+(qb[n]-qa[n])*fraction for n in ARM_NAMES}
        self.send_arm(pos)
        if elapsed>=self.motion_duration:
            self.stage='VERIFY'
            self.t_end=time.monotonic()
            self.send_arm(self.path[-1])
            self.info('Đã gửi hết quỹ đạo, đang kiểm tra TCP từ trạng thái phản hồi.',True)

    def verify(self):
        if self.stage!='VERIFY' or time.monotonic()-self.t_end<0.25:return
        if not self.fresh():self.abort('Mất TF hoặc joint_states tại bước kiểm tra.');return
        pos_base=self.kin.fk(self.current)
        pos_world=base_to_world(pos_base,self.base)
        error_mm=1000*math.dist(pos_world,self.goal['world'])
        theta_err=abs(math.degrees(wrap(self.kin.theta(self.current)-self.goal['theta'])))
        goal=self.goal['base']
        base_mm=1000*math.hypot(self.base[0]-goal[0],self.base[1]-goal[1])
        byaw_err=abs(math.degrees(wrap(self.base[3]-goal[2])))
        success=(error_mm<=1.0 and theta_err<=0.7)
        self.stage='DONE' if success else 'ERROR'
        self.write_trial(success,pos_world,error_mm,theta_err,base_mm,byaw_err)
        if success:self.info('HOÀN THÀNH: sai số TCP world %.3f mm; θ %.3f°; sai số dừng Base %.1f mm.'%(error_mm,theta_err,base_mm),True)
        else:self.info('ĐÃ DI CHUYỂN nhưng TCP chưa đạt ngưỡng kiểm tra: XYZ %.3f mm, θ %.3f°. Xem CSV.'%(error_mm,theta_err),True)

    def write_trial(self,success,pos_world,error_mm,theta_err,base_mm,byaw_err):
        try:
            self.file.parent.mkdir(parents=True,exist_ok=True)
            fresh=not self.file.exists() or self.file.stat().st_size==0
            with self.file.open('a',newline='',encoding='utf-8') as fp:
                w=csv.writer(fp)
                if fresh:
                    w.writerow(['timestamp','success','base_target_x_m','base_target_y_m','base_target_yaw_deg',
                                'base_final_x_m','base_final_y_m','base_final_yaw_deg','base_error_mm','base_yaw_error_deg',
                                'tcp_target_world_x_m','tcp_target_world_y_m','tcp_target_world_z_m','theta_target_deg',
                                'tcp_fk_world_x_m','tcp_fk_world_y_m','tcp_fk_world_z_m','tcp_error_world_mm','theta_error_deg',
                                'allow_sarrus','final_sarrus_m','base_duration_s','arm_duration_s','total_duration_s']+list(ARM_NAMES))
                g=self.goal
                w.writerow([datetime.now().isoformat(timespec='seconds'),int(success),
                            round(g['base'][0],6),round(g['base'][1],6),round(math.degrees(g['base'][2]),3),
                            round(self.base[0],6),round(self.base[1],6),round(math.degrees(self.base[3]),3),round(base_mm,3),round(byaw_err,3),
                            *[round(x,6) for x in g['world']],round(math.degrees(g['theta']),3),
                            *[round(x,6) for x in pos_world],round(error_mm,3),round(theta_err,3),int(g['allow']),
                            round(self.current['joint_1_sarrus'],6),round(self.t_nav_end-self.t_start,3),
                            round(self.motion_duration,3),round(time.monotonic()-self.t_start,3),
                            *[round(self.current[n],6) for n in ARM_NAMES]])
        except Exception as exc:self.get_logger().error('CSV failed: '+str(exc))

    def abort(self,reason):
        self.send_velocity()
        if self.stage=='ARM_MOVING' and self.last_js>-1e9:
            self.send_arm(self.current)
        self.stage='ERROR'
        self.info(reason,True)

    def stop(self):
        self.send_velocity()
        if self.stage in ('ARM_MOVING','VERIFY') and self.fresh():self.send_arm(self.current)
        self.stage='STOPPED'
        self.info('ĐÃ DỪNG: Mobile = 0, giữ tư thế các khớp. Để chạy lại, nhập mục tiêu và bấm CHẠY.',True)

    def manual(self):
        self.stop()
        self.manual_pub.publish(Empty())
        self.info('Đã trả quyền cho thanh trượt khớp; Mobile vẫn đang dừng.',True)

    @staticmethod
    def point(xyz):
        p=Point();p.x,p.y,p.z=(float(a) for a in xyz);return p

    @staticmethod
    def new_marker(ns,idx,typ,color,scale):
        m=Marker();m.header.frame_id='world';m.header.stamp.sec=0;m.header.stamp.nanosec=0
        m.ns=ns;m.id=idx;m.type=typ;m.action=Marker.ADD;m.frame_locked=True
        m.pose.orientation.w=1.0
        m.scale.x,m.scale.y,m.scale.z=[float(a) for a in scale]
        m.color.r,m.color.g,m.color.b,m.color.a=[float(a) for a in color]
        return m

    def markers(self):
        arr=MarkerArray()
        if self.goal is not None:
            target=self.new_marker('auto_tcp_goal',1,Marker.SPHERE,(1.0,0.30,0.1,1.0),(.026,)*3)
            target.pose.position=self.point(self.goal['world'])
            arr.markers.append(target)
            bx,by,yaw=self.goal['base']
            arrow=self.new_marker('auto_base_stop',2,Marker.ARROW,(1.,.78,.08,.95),(.012,.032,.045))
            b_z=self.base[2] if self.base else 0.11
            arrow.points=[self.point((bx,by,b_z)),self.point((bx+.13*math.cos(yaw),by+.13*math.sin(yaw),b_z))]
            arr.markers.append(arrow)
            if len(self.base_track)>1:
                line=self.new_marker('auto_base_path',3,Marker.LINE_STRIP,(0.25,.65,1.,.95),(.006,0.,0.))
                line.points=[self.point((x,y,0.012)) for x,y in self.base_track]
                arr.markers.append(line)
        if self.base is not None and self.last_js>-1e9:
            p=base_to_world(self.kin.fk(self.current),self.base)
            tcp=self.new_marker('auto_tcp_actual',4,Marker.SPHERE,(0.1,0.85,0.3,1.),(.016,)*3)
            tcp.pose.position=self.point(p)
            arr.markers.append(tcp)
        for ns,idx in [('auto_tcp_goal',1),('auto_base_stop',2),('auto_base_path',3),('auto_tcp_actual',4)]:
            if not any(m.ns==ns and m.id==idx for m in arr.markers):
                d=Marker();d.header.frame_id='world';d.ns=ns;d.id=idx;d.action=Marker.DELETE
                arr.markers.append(d)
        self.marker_pub.publish(arr)

    def tick(self):
        if self.closing:return
        try:
            for _ in range(7):rclpy.spin_once(self,timeout_sec=0.0)
            now=time.monotonic()
            if self.base is not None:
                self.base_text.set('Base world: X=%.3f, Y=%.3f m, yaw=%.1f°'%(
                    self.base[0],self.base[1],math.degrees(self.base[3])))
            if self.base is not None and self.last_js>-1e9:
                world_pt=base_to_world(self.kin.fk(self.current),self.base)
                self.tcp_text.set('TCP world: X=%.3f Y=%.3f Z=%.3f m | θ=%.1f°'%(
                    *world_pt,math.degrees(self.kin.theta(self.current))))
            if self.stage in ('CHECK_IK','DRIVING','FINAL_IK','ARM_MOVING','VERIFY'):
                if not self.fresh():self.abort('Mất TF hoặc /joint_states >1 giây; đã dừng.')
                elif self.stage in ('CHECK_IK','FINAL_IK'):
                    self.finish_ik()
                elif self.stage=='DRIVING':self.nav_tick()
                elif self.stage=='ARM_MOVING':self.arm_tick()
                elif self.stage=='VERIFY':self.verify()
            if now-self.last_marker>0.16:
                self.last_marker=now
                self.markers()
        except Exception as exc:
            self.get_logger().error('Auto tick failed: '+repr(exc))
            self.abort('Lỗi xử lý, đã dừng nhiệm vụ: '+str(exc))
        finally:
            if not self.closing:
                try:self.root.after(35,self.tick)
                except tk.TclError:pass

    def close(self):
        if self.closing:return
        self.closing=True
        self.send_velocity()
        self.stage='STOPPED'
        self.ik_pool.shutdown(wait=False,cancel_futures=True)
        self.root.destroy()


def main(args=None):
    rclpy.init(args=args)
    node=AutoTask()
    try:node.root.mainloop()
    except KeyboardInterrupt:pass
    finally:
        if not node.closing:node.close()
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()


if __name__=='__main__':main()
