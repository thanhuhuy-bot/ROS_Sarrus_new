#!/usr/bin/env python3
"""Mirror V4.7 world->base pose and eight original CAD Sarrus poses to Gazebo.

This node publishes visualization poses only; it publishes no TF and never
modifies Mobile Base commands or IK. Gazebo Classic plugin reads the PoseArray.
"""
import json
import math
from pathlib import Path
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from geometry_msgs.msg import PoseArray, Pose
from tf2_msgs.msg import TFMessage
from ament_index_python.packages import get_package_share_directory
from sarrus_rigid_math import link_poses_at, quatmul, rotate


class GazeboPoseBridge(Node):
    def __init__(self):
        super().__init__('as3_gazebo_pose_bridge')
        config = Path(get_package_share_directory('as3_description'))/'config/sarrus_visual_parts.json'
        self.parts = json.loads(config.read_text(encoding='utf-8'))['parts']
        self.lift = 0.0
        self.pub = self.create_publisher(PoseArray, '/as3/gazebo/kinematic_poses', 10)
        self.create_subscription(JointState, '/joint_states', self.on_joint, 10)
        self.create_subscription(TFMessage, '/tf', self.on_tf, 10)
        self.get_logger().info('Gazebo mirror: original Assem3 CAD, 8 rigid Sarrus links')

    def on_joint(self, msg):
        if 'joint_1_sarrus' in msg.name:
            idx = msg.name.index('joint_1_sarrus')
            if idx < len(msg.position):
                v = float(msg.position[idx])
                if math.isfinite(v):
                    self.lift = max(0.0, min(.045, v))

    @staticmethod
    def pose(t, q):
        p = Pose()
        p.position.x, p.position.y, p.position.z = map(float, t)
        p.orientation.x, p.orientation.y, p.orientation.z, p.orientation.w = map(float, q)
        return p

    def on_tf(self, msg):
        base_tf = next((tf for tf in msg.transforms
                        if tf.header.frame_id == 'world' and tf.child_frame_id == 'base_link'), None)
        if base_tf is None:
            return
        t = base_tf.transform.translation
        q = base_tf.transform.rotation
        bp = [t.x, t.y, t.z]
        bq = [q.x, q.y, q.z, q.w]
        out = PoseArray()
        out.header = base_tf.header
        out.poses.append(self.pose(bp, bq))
        for side in ('south', 'east', 'north', 'west'):
            poses = link_poses_at(self.parts[side], self.lift)
            for which in ('lower', 'upper'):
                dat = poses[which]
                rt = rotate(bq, dat['position'])
                wp = [bp[i] + rt[i] for i in range(3)]
                wq = quatmul(bq, dat['quat'])
                out.poses.append(self.pose(wp, wq))
        self.pub.publish(out)


def main(args=None):
    rclpy.init(args=args)
    n = GazeboPoseBridge()
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
