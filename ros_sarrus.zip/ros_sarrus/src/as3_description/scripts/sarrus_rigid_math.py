"""Rigid CAD mesh kinematics for the original SolidWorks Assem3 Sarrus.

Geometric measurements come from the exact Assem3 saved joint poses of eight
SL2 lower/SL4 upper rigid parts. Both pivots of each part are x=+/-0.021 m in
part-local coordinates. Each link stays 0.042 m long, never scaled.

The saved SolidWorks upper plate is at joint_1_sarrus ~=0.031081422 m in the
folded-zero ROS model. A reference-pose reconstruction test is provided.
"""
import math

REFERENCE_LIFT = 0.031081422
MIN_LIFT = 0.0
MAX_LIFT = 0.045
HALF_LINK_LENGTH = 0.021


def plus(a,b):
    return [a[i]+b[i] for i in range(3)]


def minus(a,b):
    return [a[i]-b[i] for i in range(3)]


def times(a,s):
    return [x*s for x in a]


def norm(a):
    return math.sqrt(sum(x*x for x in a))


def normalize(a):
    n=norm(a)
    if n<1e-14: raise ValueError('near-zero vector')
    return [x/n for x in a]


def cross(a,b):
    return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]


def dot(a,b):
    return sum(x*y for x,y in zip(a,b))


def quatmul(a,b):
    ax,ay,az,aw=a;bx,by,bz,bw=b
    return [aw*bx+ax*bw+ay*bz-az*by,
            aw*by-ax*bz+ay*bw+az*bx,
            aw*bz+ax*by-ay*bx+az*bw,
            aw*bw-ax*bx-ay*by-az*bz]


def quat_conj(q):
    return [-q[0],-q[1],-q[2],q[3]]


def rotate(q,xyz):
    return quatmul(quatmul(q,[*xyz,0]),quat_conj(q))[:3]


def quat_between(a,b):
    a=normalize(a);b=normalize(b)
    v=cross(a,b)
    w=1.0+dot(a,b)
    if w<1e-12:
        anchor=[1,0,0] if abs(a[0])<.8 else [0,1,0]
        v=normalize(cross(a,anchor))
        w=0.0
    return normalize([*v,w])


def setup_side(parts):
    lo,hi=parts['lower'],parts['upper']
    p0,p1=lo['p'],hi['p']
    u0=rotate(lo['quat'],[1,0,0])
    u1=rotate(hi['quat'],[1,0,0])
    # In original assembly the center hinge is at +21mm on both link meshes.
    # Assert the CAD placements meet exactly there; don't silently invent axes.
    a=(p1[2]-p0[2])/(u0[2]-u1[2])
    if abs(a-HALF_LINK_LENGTH)>5e-6:
        raise ValueError('Unexpected CAD Sarrus hinge offset: %s' % a)
    bottom=minus(p0,times(u0,a))
    top_saved=minus(p1,times(u1,a))
    knee_0=plus(p0,times(u0,a))
    knee_1=plus(p1,times(u1,a))
    if norm(minus(knee_0,knee_1))>1e-6:
        raise ValueError('SolidWorks link meshes do not share knee center')
    if math.hypot(bottom[0]-top_saved[0], bottom[1]-top_saved[1])>1e-6:
        raise ValueError('SolidWorks lower/top hinge XY disagree')
    inside=normalize([knee_0[0]-bottom[0],knee_0[1]-bottom[1],0])
    length=2*a
    return {'bottom':bottom,'top_saved':top_saved,'inside':inside,
            'hinge_offset':a,'link_length':length}


def link_poses_at(parts,lift):
    """Return exact rigid placement poses for 2 original SolidWorks STL meshes.

    Same link geometry at every pose; only rigid translation/rotation changes.
    """
    if lift < MIN_LIFT-1e-8 or lift > MAX_LIFT+1e-8:
        raise ValueError('Sarrus lift out of range')
    setup=setup_side(parts)
    bottom=setup['bottom']
    top=plus(setup['top_saved'],[0,0,lift-REFERENCE_LIFT])
    h=top[2]-bottom[2]
    L=setup['link_length']
    if abs(h) > 2*L + 1e-10:
        raise ValueError('Requested lift exceeds rigid CAD link length')
    spread=math.sqrt(max(0,L*L-h*h/4))
    knee=plus(bottom, plus(times(setup['inside'],spread),[0,0,h/2]))
    out={}
    for label,outer in [('lower',bottom),('upper',top)]:
        p=parts[label]
        q_saved=p['quat']
        u_saved=rotate(q_saved,[1,0,0])
        u_new=normalize(minus(knee,outer))
        q_new=normalize(quatmul(quat_between(u_saved,u_new),q_saved))
        p_new=plus(outer,times(rotate(q_new,[1,0,0]),setup['hinge_offset']))
        out[label]={'position':p_new,'quat':q_new,'mesh':p['mesh'],
                    'outer':outer,'knee':knee,'scale':[1.,1.,1.]}
    return out
