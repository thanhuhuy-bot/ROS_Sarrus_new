#!/usr/bin/env python3
"""Generate a Gazebo Classic SDF 1.6 kinematic Assem3 model from the original URDF.

No SolidWorks STL or joint dimension is modified. Sarrus originals become
independent gravity-free visual links, driven by the optional mirror plugin.
"""
import argparse
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET
from sarrus_rigid_math import link_poses_at, quatmul, rotate

COLORS = {
    'base': (0.16, 0.35, 0.65, 1.0),
    'sarrus': (0.78, 0.46, 0.15, 1.0),
    'arm': (0.67, 0.69, 0.75, 1.0),
    'wheels': (0.10, 0.12, 0.14, 1.0),
    'misc': (0.50, 0.53, 0.57, 1.0),
}


def floats(s, default):
    return [float(x) for x in (s or default).split()]


def rpy_to_quat(r, p, y):
    cr, sr = math.cos(r/2), math.sin(r/2)
    cp, sp = math.cos(p/2), math.sin(p/2)
    cy, sy = math.cos(y/2), math.sin(y/2)
    return [sr*cp*cy-cr*sp*sy, cr*sp*cy+sr*cp*sy,
            cr*cp*sy-sr*sp*cy, cr*cp*cy+sr*sp*sy]


def quat_to_rpy(q):
    x, y, z, w = q
    return [math.atan2(2*(w*x+y*z), 1-2*(x*x+y*y)),
            math.asin(max(-1., min(1., 2*(w*y-z*x)))),
            math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))]


def compose(a, b):
    pa, qa = a
    pb, qb = b
    rotated = rotate(qa, pb)
    return ([pa[i] + rotated[i] for i in range(3)], quatmul(qa, qb))


def pose6(p, q):
    return ' '.join('{:.11g}'.format(x) for x in (*p, *quat_to_rpy(q)))


def add(el, tag, text=None, **attrs):
    child = ET.SubElement(el, tag, attrs)
    if text is not None:
        child.text = str(text)
    return child


def add_link(model, name, p, q):
    link = add(model, 'link', name=name)
    add(link, 'pose', pose6(p,q))
    add(link, 'gravity', 'false')
    add(link, 'self_collide', 'false')
    inertial = add(link, 'inertial')
    add(inertial, 'mass', '0.5')
    I = add(inertial, 'inertia')
    for k in ('ixx','iyy','izz'):
        add(I,k,'0.001')
    for k in ('ixy','ixz','iyz'):
        add(I,k,'0')
    # No collision geometries in kinematic preview: Gazebo cannot resolve
    # a closed-chain Sarrus with the independent CAD visual links.
    return link


def add_mesh_visual(link, name, origin, rpy, mesh_path, color):
    vis = add(link, 'visual', name=name)
    add(vis,'pose',' '.join(str(v) for v in (*origin, *rpy)))
    geom = add(vis,'geometry')
    mesh=add(geom,'mesh')
    add(mesh,'uri',mesh_path.as_uri())
    add(mesh,'scale','1 1 1')
    mat=add(vis,'material')
    c=' '.join(str(v) for v in color)
    add(mat,'ambient',c)
    add(mat,'diffuse',c)
    return vis


def generate(share, destination):
    urdf = ET.parse(share/'urdf/as3_movable.urdf').getroot()
    sdftree=ET.Element('sdf',version='1.6')
    model=add(sdftree,'model',name='as3_solidworks')
    add(model,'pose','0 0 0.11 0 0 0')
    add(model,'static','false')
    # FK for zero-pose link frames, starting at base_link.
    world_in_base={'base_link':([0.,0.,0.],[0.,0.,0.,1.])}
    joints=list(urdf.findall('joint'))
    todo=joints[:]
    while todo:
        progress=False
        for j in todo[:]:
            pn=j.find('parent').attrib['link']
            cn=j.find('child').attrib['link']
            if pn not in world_in_base: continue
            o=j.find('origin')
            xyz=floats(o.get('xyz') if o is not None else None,'0 0 0')
            rpy=floats(o.get('rpy') if o is not None else None,'0 0 0')
            world_in_base[cn]=compose(world_in_base[pn],(xyz,rpy_to_quat(*rpy)))
            todo.remove(j)
            progress=True
        if not progress:
            raise RuntimeError('Unconnected URDF tree: '+','.join(j.get('name') for j in todo))
    for l in urdf.findall('link'):
        name=l.get('name')
        link=add_link(model,name,*world_in_base[name])
        for vis in l.findall('visual'):
            o=vis.find('origin')
            pos=floats(o.get('xyz') if o is not None else None,'0 0 0')
            rot=floats(o.get('rpy') if o is not None else None,'0 0 0')
            mesh=vis.find('geometry/mesh')
            if mesh is None:
                continue
            fn=mesh.get('filename').rsplit('/',1)[-1]
            path=share/'meshes'/fn
            if not path.is_file(): raise FileNotFoundError(path)
            color=COLORS.get(vis.find('material').get('name') if vis.find('material') is not None else '',(0.7,0.7,0.7,1.))
            add_mesh_visual(link,vis.get('name','visual'),pos,rot,path,color)
    for j in joints:
        typ=j.get('type')
        if typ=='fixed':
            kind='fixed'
        elif typ=='prismatic':
            kind='prismatic'
        else:
            kind='revolute'
        joint=add(model,'joint',name=j.get('name'),type=kind)
        add(joint,'pose','0 0 0 0 0 0')
        add(joint,'parent',j.find('parent').get('link'))
        add(joint,'child',j.find('child').get('link'))
        if typ!='fixed':
            ax=add(joint,'axis')
            add(ax,'xyz',j.find('axis').get('xyz'))
            lim=add(ax,'limit')
            jlim=j.find('limit')
            if typ=='continuous':
                low,high='-1000000','1000000'
            else:
                low,high=jlim.get('lower'),jlim.get('upper')
            add(lim,'lower',low)
            add(lim,'upper',high)
            add(lim,'effort',jlim.get('effort','100') if jlim is not None else '100')
            add(lim,'velocity',jlim.get('velocity','1') if jlim is not None else '1')
    parts=json.loads((share/'config/sarrus_visual_parts.json').read_text())['parts']
    for side in ('south','east','north','west'):
        pose_pair=link_poses_at(parts[side],0.0)
        for which in ('lower','upper'):
            dat=pose_pair[which]
            name=f'sarrus_cad_{side}_{which}'
            l=add_link(model,name,dat['position'],dat['quat'])
            add_mesh_visual(l,name+'_mesh',[0,0,0],[0,0,0],share/'meshes'/dat['mesh'],
                            COLORS['base' if which=='lower' else 'sarrus'])
    plug=add(model,'plugin',name='as3_gazebo_kinematic_mirror',filename='libas3_gazebo_mirror.so')
    ros=add(plug,'ros')
    add(ros,'namespace','/')
    ET.indent(sdftree,space='  ')
    destination.parent.mkdir(parents=True,exist_ok=True)
    ET.ElementTree(sdftree).write(destination,encoding='utf-8',xml_declaration=True)
    return destination


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--share',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    a=parser.parse_args()
    print(generate(a.share.resolve(),a.output.resolve()))


if __name__=='__main__':
    main()
