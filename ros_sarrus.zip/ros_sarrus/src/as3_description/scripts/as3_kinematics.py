#!/usr/bin/env python3
"""V4.8.5: URDF-based FK and resolved-rate Jacobian pseudoinverse IK.

IK law (task-space pose x, with optional pitch):
    qdot = J^+ [xd_dot + K (xd - x)] + (I - J^+ J) z0
    z0   = -k (q - q_mid) / (q_max - q_min)^2

The sign of k is chosen to move toward joint midpoints. When Sarrus is
locked, its coordinate is excluded from the Jacobian and remains fixed.

All geometric data and joint limits come from the original Assem3 URDF.
The Sarrus mesh/visualization and V4.7 single-owner TF implementation are
not modified here. Position-only mode uses a 3xN Jacobian; optional TCP
pitch adds a fourth task row, matching the 4x5 matrix in the supplied slide.
"""
import math
import xml.etree.ElementTree as ET

import numpy as np

ARM_NAMES = ('joint_1_sarrus','joint_2_yaw','joint_3_shoulder',
             'joint_4_elbow','joint_5_wrist')
PITCH_NAMES = ('joint_3_shoulder','joint_4_elbow','joint_5_wrist')


def vec(text, default='0 0 0'):
    return tuple(float(v) for v in (text if text is not None else default).split())


def qmul(a,b):
    x,y,z,w=a; X,Y,Z,W=b
    return (w*X+x*W+y*Z-z*Y, w*Y-x*Z+y*W+z*X,
            w*Z+x*Y-y*X+z*W, w*W-x*X-y*Y-z*Z)


def qrot(q,v):
    x,y,z,w=q
    tx=2*(y*v[2]-z*v[1]); ty=2*(z*v[0]-x*v[2]); tz=2*(x*v[1]-y*v[0])
    return (v[0]+w*tx+(y*tz-z*ty),
            v[1]+w*ty+(z*tx-x*tz),
            v[2]+w*tz+(x*ty-y*tx))


def qrpy(r,p,y):
    cr,sr=math.cos(r/2),math.sin(r/2)
    cp,sp=math.cos(p/2),math.sin(p/2)
    cy,sy=math.cos(y/2),math.sin(y/2)
    return (sr*cp*cy-cr*sp*sy, cr*sp*cy+sr*cp*sy,
            cr*cp*sy+sr*sp*cy, cr*cp*cy-sr*sp*sy)


def qaxis(axis, theta):
    s=math.sin(theta/2)
    return (axis[0]*s,axis[1]*s,axis[2]*s,math.cos(theta/2))


class RobotKinematics:
    """Forward kinematics and closed-loop differential IK for the Assem3 robot."""

    def __init__(self, urdf_path):
        root=ET.parse(str(urdf_path)).getroot()
        by_child={}
        self.limits={}
        origin_pitch={}
        for node in root.findall('joint'):
            parent=node.find('parent').get('link')
            child=node.find('child').get('link')
            typ=node.get('type')
            origin=node.find('origin')
            xyz=vec(origin.get('xyz') if origin is not None else None)
            rpy=vec(origin.get('rpy') if origin is not None else None)
            axis_el=node.find('axis')
            axis=vec(axis_el.get('xyz') if axis_el is not None else None,'1 0 0')
            norm=math.sqrt(sum(v*v for v in axis))
            if norm < 1e-12:
                raise ValueError('Invalid joint axis in URDF: '+node.get('name'))
            axis=tuple(v/norm for v in axis)
            name=node.get('name')
            by_child[child]=(name,typ,parent,xyz,qrpy(*rpy),axis)
            origin_pitch[name]=rpy[1]
            lim=node.find('limit')
            if lim is not None and typ!='fixed':
                self.limits[name]=(float(lim.get('lower')),float(lim.get('upper')))
        chain=[]
        link='tcp'
        while link!='base_link':
            if link not in by_child:
                raise ValueError('No base_link to tcp chain')
            j=by_child[link]
            chain.insert(0,j)
            link=j[2]
        self.chain=chain
        if any(name not in self.limits for name in ARM_NAMES):
            raise ValueError('Missing arm joint limits in Assem3 URDF')
        self.pitch_zero=sum(origin_pitch.get(j[0],0.0) for j in chain)
        # All joints after yaw in the provided Assem3 URDF rotate about +y.
        # Reject pitch mode if the model geometry is later changed incompatibly.
        self.pitch_supported=all(
            (name not in PITCH_NAMES or (typ=='revolute' and
                np.allclose(axis,(0.,1.,0.),atol=1e-9)))
            for name,typ,_,_,_,axis in chain)

    def fk_jacobian(self, vals, names=ARM_NAMES):
        """Exact position geometric Jacobian: revolute a x (p_tcp-p_j), prismatic a.

        Axes and joint origins are first transformed through *each URDF origin
        and joint rotation*; no simplified DH lengths are substituted.
        """
        p=np.zeros(3,dtype=float)
        quat=(0.0,0.0,0.0,1.0)
        moving={}
        for name,typ,parent,offset,q_origin,axis in self.chain:
            p+=np.asarray(qrot(quat,offset))
            quat=qmul(quat,q_origin)
            if typ in ('revolute','continuous','prismatic'):
                world_axis=np.asarray(qrot(quat,axis),dtype=float)
                moving[name]=(typ,p.copy(),world_axis)
            value=float(vals.get(name,0.0))
            if typ=='prismatic':
                p+=value*world_axis
            elif typ in ('revolute','continuous'):
                quat=qmul(quat,qaxis(axis,value))
        J=np.zeros((3,len(names)),dtype=float)
        for k,name in enumerate(names):
            if name not in moving:
                raise ValueError('Joint not found in kinematic chain: '+name)
            typ,joint_pos,world_axis=moving[name]
            J[:,k]=(world_axis if typ=='prismatic'
                    else np.cross(world_axis,p-joint_pos))
        return p,J

    def fk(self, vals):
        return tuple(float(v) for v in self.fk_jacobian(vals,())[0])

    def pitch(self, vals):
        if not self.pitch_supported:
            raise ValueError('TCP pitch requires the original +Y revolute axes')
        return float(self.pitch_zero+sum(vals.get(n,0.0) for n in PITCH_NAMES))

    def theta(self, vals):
        """Theta from the user's 4D FK: theta = q3 + q4 + q5 [rad].

        The CAD/URDF tool-frame pitch contains a small fixed origin-angle
        offset, self.pitch_zero. Hence pitch = theta + pitch_zero.
        """
        return float(sum(vals.get(n,0.0) for n in PITCH_NAMES))

    @staticmethod
    def _joint_mid_cost(q,lo,hi):
        norm=(q-(hi+lo)*0.5)/(hi-lo)
        return float(np.dot(norm,norm))

    def ik_with_path(self, target, current, allow_sarrus=False, tolerance=0.0002,
                     pitch_target=None):
        """Integrate the resolved-rate feedback law to a stationary Cartesian goal.

        :returns: (joint_dict | None, xyz_residual_m, list[joint_dict]).
        The path is the sequence of differential IK integration steps, not a
        straight-line joint interpolation. No success is returned above the
        requested Cartesian tolerance (and 0.5 degree when pitch enabled).
        """
        target=np.asarray(target,dtype=float)
        if target.shape!=(3,) or not np.all(np.isfinite(target)):
            return None,float('inf'),[]
        if pitch_target is not None and (not math.isfinite(pitch_target) or
                                         not self.pitch_supported):
            return None,float('inf'),[]
        names=ARM_NAMES if allow_sarrus else ARM_NAMES[1:]
        start={name:float(current.get(name,0.0)) for name in ARM_NAMES}
        low=np.array([self.limits[n][0] for n in names],dtype=float)
        high=np.array([self.limits[n][1] for n in names],dtype=float)
        q_start=np.clip(np.array([start[n] for n in names],dtype=float),low,high)
        n=len(names)
        # Normalize prismatic units before SVD: u_sarrus=q_sarrus / 0.1 m;
        # u_revolute=q_revolute / 1 rad. J_u is well-scaled for Moore-Penrose.
        scale=np.array([0.1 if name=='joint_1_sarrus' else 1.0 for name in names])
        u_span=(high-low)/scale
        u_mid=(high+low)/(2*scale)
        mode_pitch=pitch_target is not None
        pitch_scale=0.12  # metre/radian; task weighting to balance XYZ and pitch
        # Seed perturbations address the rank loss of the fully horizontal zero pose.
        # Every path begins from the actual current joint state.
        perturbations=[[0.0]*n]
        for shoulder,elbow in ((0.10,0.0),(-0.10,0.0),
                                (0.0,0.12),(0.0,-0.12),
                                (0.12,-0.12),(-0.12,0.12),
                                (0.20,-0.12),(-0.20,0.12)):
            v=[0.0]*n
            v[names.index('joint_3_shoulder')]=shoulder
            v[names.index('joint_4_elbow')]=elbow
            perturbations.append(v)
        best_error=float('inf')
        best_orient=float('inf')
        best_path=[]
        for perturb in perturbations:
            x=np.clip(q_start+np.asarray(perturb),low,high)
            path=[dict(start)]
            if np.linalg.norm(x-q_start)>1e-9:
                perturbed=dict(start)
                perturbed.update(zip(names,x.tolist()))
                path.append(perturbed)
            for _ in range(370):
                q=dict(start)
                q.update(zip(names,x.tolist()))
                pos,J=self.fk_jacobian(q,names)
                e_xyz=target-pos
                pos_err=float(np.linalg.norm(e_xyz))
                pitch_err=0.0 if not mode_pitch else float(pitch_target-self.pitch(q))
                if pos_err<best_error and (not mode_pitch or abs(pitch_err)<=max(best_orient,0.035)):
                    best_error=pos_err
                    best_orient=abs(pitch_err)
                    best_path=path.copy()
                if pos_err<=tolerance and (not mode_pitch or abs(pitch_err)<=math.radians(0.5)):
                    return q,pos_err,path
                if mode_pitch:
                    j_pitch=np.array([1.0 if name in PITCH_NAMES else 0.0 for name in names])
                    J_task=np.vstack((J,pitch_scale*j_pitch))
                    e_task=np.concatenate((e_xyz,[pitch_scale*pitch_err]))
                else:
                    J_task=J
                    e_task=e_xyz
                Ju=J_task*scale[np.newaxis,:]
                # Moore-Penrose inverse computed from SVD, with a numerical
                # cutoff for zero singular values at singular configurations.
                pinv=np.linalg.pinv(Ju,rcond=1e-5)
                N=np.eye(n)-pinv@Ju
                u=x/scale
                z0=-0.08*(u-u_mid)/(u_span*u_span)
                # Stationary target: xd_dot=0. K=2.8/s is the feedback gain.
                du=pinv@(2.8*e_task)+N@z0
                dq=scale*du*0.04
                if not np.all(np.isfinite(dq)):
                    break
                # Limit the magnitude per integration step, respecting the
                # very different units of the lift and revolute joints.
                max_step=np.array([0.002 if name=='joint_1_sarrus' else 0.065
                                   for name in names])
                cap=max(1.0,float(np.max(np.abs(dq)/max_step)))
                dq=dq/cap
                old_task=float(np.linalg.norm(e_task))
                old_cost=self._joint_mid_cost(x,low,high)
                accepted=False
                for alpha in (1.0,0.5,0.25,0.1,0.04):
                    xx=np.clip(x+alpha*dq,low,high)
                    if float(np.linalg.norm(xx-x))<1e-12:
                        continue
                    trial=dict(start);trial.update(zip(names,xx.tolist()))
                    trial_pos=self.fk(trial)
                    trial_e=np.asarray(target)-np.asarray(trial_pos)
                    if mode_pitch:
                        trial_task=np.concatenate((trial_e,
                             [pitch_scale*(pitch_target-self.pitch(trial))]))
                    else:
                        trial_task=trial_e
                    trial_norm=float(np.linalg.norm(trial_task))
                    # Secondary null-space motion is allowed only when it
                    # does not compromise the principal task materially.
                    new_cost=self._joint_mid_cost(xx,low,high)
                    if trial_norm<old_task-1e-10 or (
                       trial_norm<=old_task+2e-7 and new_cost+1e-9<old_cost):
                        x=xx
                        path.append(trial)
                        accepted=True
                        break
                if not accepted:
                    break
            # Continue with a different small perturbation when current
            # configuration is locally singular or outside reachable region.
        return None,best_error,best_path

    def ik(self,target,current,allow_sarrus=False,tolerance=0.0002,
           pitch_target=None):
        q,err,_=self.ik_with_path(target,current,allow_sarrus,tolerance,pitch_target)
        return q,err
