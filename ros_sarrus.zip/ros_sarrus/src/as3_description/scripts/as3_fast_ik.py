#!/usr/bin/env python3
"""Fast *screening* IK for candidate mobile base poses.

Uses the exact URDF geometry and Jacobian from RobotKinematics.  This
solver is intentionally limited to screening candidate poses; the original
resolved-rate Jacobian IK remains responsible for producing the arm path.
False negatives are possible, so a budgeted original-IK fallback follows.
"""
import math
import numpy as np
from as3_kinematics import ARM_NAMES, PITCH_NAMES


def quick_ik(kin, target, current, allow_sarrus=True, pitch_target=None,
             tolerance=0.0002, iterations=28):
    names = ARM_NAMES if allow_sarrus else ARM_NAMES[1:]
    target = np.asarray(target, dtype=float)
    low = np.array([kin.limits[n][0] for n in names])
    high = np.array([kin.limits[n][1] for n in names])
    scale = np.array([0.1 if n == 'joint_1_sarrus' else 1.0 for n in names])
    start = np.array([current.get(n, 0.0) for n in names])
    start = np.clip(start, low, high)
    pitch_mode = pitch_target is not None
    pitch_scale = 0.12
    j_pitch = np.array([1.0 if n in PITCH_NAMES else 0.0 for n in names])
    per_step = np.array([0.009 if n == 'joint_1_sarrus' else 0.40 for n in names])
    seed_deltas = ((0.0, 0.0), (0.26, -0.20), (-0.26, 0.20),
                   (0.0, 0.25), (0.0, -0.25))
    best = math.inf
    for shoulder, elbow in seed_deltas:
        qv = start.copy()
        qv[names.index('joint_3_shoulder')] += shoulder
        qv[names.index('joint_4_elbow')] += elbow
        qv = np.clip(qv, low, high)
        for _ in range(iterations):
            q = dict(current)
            q.update(zip(names, qv))
            pos, jac = kin.fk_jacobian(q, names)
            delta = target - pos
            pos_error = float(np.linalg.norm(delta))
            angle_err = 0 if not pitch_mode else float(pitch_target - kin.pitch(q))
            if pos_error < best:
                best = pos_error
            if pos_error <= tolerance and (not pitch_mode or abs(angle_err) <= math.radians(0.5)):
                return q, pos_error
            if pitch_mode:
                err = np.concatenate((delta, [pitch_scale * angle_err]))
                task_jac = np.vstack((jac, pitch_scale * j_pitch))
            else:
                err = delta
                task_jac = jac
            jac_scaled = task_jac * scale[np.newaxis, :]
            # Full pseudoinverse Newton step (not slow small-time-step tracking).
            du = np.linalg.pinv(jac_scaled, rcond=1e-5) @ err
            dq = scale * du
            cap = max(1.0, float(np.max(np.abs(dq) / per_step)))
            dq /= cap
            current_loss = float(np.linalg.norm(err))
            accepted = False
            for fraction in (1.0, 0.5, 0.25, 0.125):
                nxt = np.clip(qv + fraction*dq, low, high)
                if np.max(np.abs(nxt - qv)) < 1e-10:
                    continue
                trial = dict(current)
                trial.update(zip(names, nxt))
                p = kin.fk(trial)
                trial_diff = target - np.asarray(p)
                if pitch_mode:
                    loss = math.hypot(float(np.linalg.norm(trial_diff)),
                                      pitch_scale*(pitch_target - kin.pitch(trial)))
                else:
                    loss = float(np.linalg.norm(trial_diff))
                if loss < current_loss - 1e-9:
                    qv = nxt
                    accepted = True
                    break
            if not accepted:
                break
    return None, best


def find_base_stop_fast(kin, world_goal, theta_rad, allow_sarrus,
                        base_at_start, joints_at_start, candidate_poses,
                        should_cancel=None, on_progress=None,
                        max_candidates=45, time_budget_s=10.0,
                        slow_fallback_candidates=12):
    """Screen candidates cheaply, validate successful fast results via original IK.

    Returns (base_pose_xyz_yaw or None, number_unique_candidates, best_error).
    A bounded original-IK fallback protects against quick solver false negatives.
    Timing is best-effort: one original IK call cannot be interrupted midway.
    """
    from as3_auto_math import world_to_base
    import time
    now = time.monotonic
    deadline = now() + time_budget_s
    max_candidates = min(max_candidates, len(candidate_poses))
    checked = set()
    best = math.inf
    pitch = theta_rad + kin.pitch_zero
    def report(index):
        if on_progress is not None:
            on_progress(index)
    def cancelled():
        return should_cancel is not None and should_cancel()
    # Pass 1: very fast approximate Newton IK for all ranked candidates.
    for i, (bx,by,yaw) in enumerate(candidate_poses[:max_candidates]):
        if cancelled() or now() >= deadline:
            break
        checked.add(i)
        report(len(checked))
        pose = (bx,by,base_at_start[2],yaw)
        local = world_to_base(world_goal,pose)
        q,err = quick_ik(kin, local, joints_at_start, allow_sarrus, pitch)
        best = min(best,err)
        if q is not None:
            # Verify reachability from the *current* arm configuration with the
            # original Jacobian path solver before commanding Mobile Base.
            full_q,full_err = kin.ik(local, joints_at_start, allow_sarrus, 0.0002, pitch)
            best = min(best,full_err)
            if full_q is not None:
                return pose, len(checked), best
    # Pass 2: quick IK may miss a legitimate solution. Preserve compatibility
    # with a bounded number of original exhaustive IK solves at top poses.
    for i, (bx,by,yaw) in enumerate(candidate_poses[:min(slow_fallback_candidates,max_candidates)]):
        if cancelled() or now() >= deadline:
            break
        if i not in checked:
            checked.add(i)
            report(len(checked))
        pose = (bx,by,base_at_start[2],yaw)
        local = world_to_base(world_goal,pose)
        full_q,full_err=kin.ik(local, joints_at_start, allow_sarrus, 0.0002, pitch)
        best=min(best,full_err)
        if full_q is not None:
            return pose, len(checked), best
    return None, len(checked), best


def outside_planar_reach(kin, local_xyz):
    """Conservative XY reach bound derived from the actual Assem3 URDF.

    The Sarrus translates only in Z, yaw rotates only around Z and the
    shoulder pivot is at a fixed horizontal offset from yaw.  From shoulder
    onward, the horizontal projection cannot exceed the sum of lengths of
    its fixed chain offsets, by the triangle inequality.  If a future URDF
    changes this architecture, the shortcut turns itself off (False).
    """
    chain = kin.chain
    if len(chain)<4 or [j[0] for j in chain[:3]] != [
            'joint_1_sarrus','joint_2_yaw','joint_3_shoulder']:
        return False
    lift,yaw,shoulder = chain[:3]
    ident = (0.,0.,0.,1.)
    z_axis = (0.,0.,1.)
    if lift[1]!='prismatic' or yaw[1]!='revolute' or shoulder[1]!='revolute':
        return False
    if not all(np.allclose(j[4],ident,atol=1e-8) and
               np.allclose(j[5],z_axis,atol=1e-8) for j in (lift,yaw)):
        return False
    # All pre-shoulder translations remain vertical or rotated in XY by yaw.
    radius = sum(math.hypot(*j[3][:2]) for j in chain[:3])
    radius += sum(float(np.linalg.norm(j[3])) for j in chain[3:])
    return math.hypot(float(local_xyz[0]),float(local_xyz[1])) > radius + 1e-8
