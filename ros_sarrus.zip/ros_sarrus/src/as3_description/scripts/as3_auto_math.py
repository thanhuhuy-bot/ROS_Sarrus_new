#!/usr/bin/env python3
"""V4.9 pure math: planar pose approach and world/base TCP conversion.

Units: metres, radians.  All computations use the exact world->base_link
transform observed in /tf; base origin is 0.11 m above RViz ground by default.
"""
import math


def wrap(x):
    return math.atan2(math.sin(x), math.cos(x))


def clamp(x,lo,hi):
    return max(lo,min(hi,x))


def world_to_base(world,base):
    bx,by,bz,yaw=base
    dx,dy,dz=world[0]-bx,world[1]-by,world[2]-bz
    c,s=math.cos(yaw),math.sin(yaw)
    return (c*dx+s*dy,-s*dx+c*dy,dz)


def base_to_world(local,base):
    bx,by,bz,yaw=base
    c,s=math.cos(yaw),math.sin(yaw)
    return (bx+c*local[0]-s*local[1],by+s*local[0]+c*local[1],bz+local[2])


def navigation_step(base,goal,phase,v_max=0.17,w_max=0.65):
    """Return (new_phase,v,w) for a rotate/drive/final-rotate controller.

    No navigation stack, collision checking, localization or wheel slip model.
    """
    x,y,_,yaw=base
    tx,ty,tyaw=goal
    dx,dy=tx-x,ty-y
    dist=math.hypot(dx,dy)
    yaw_error=wrap(tyaw-yaw)
    if phase not in ('ALIGN','DRIVE','FINAL','DONE'):
        phase='ALIGN'
    if phase=='ALIGN':
        if dist<0.003:
            phase='FINAL'
        else:
            e=wrap(math.atan2(dy,dx)-yaw)
            if abs(e)<0.035: phase='DRIVE'
            else: return 'ALIGN',0.0,clamp(2.4*e,-w_max,w_max)
    if phase=='DRIVE':
        if dist<0.003: phase='FINAL'
        else:
            e=wrap(math.atan2(dy,dx)-yaw)
            if abs(e)>0.55: return 'ALIGN',0.0,0.0
            v=clamp(1.5*dist,0.0,v_max)
            if abs(e)>0.30:v=0.0
            return 'DRIVE',v,clamp(2.0*e,-w_max,w_max)
    if phase=='FINAL':
        if dist>0.009: return 'ALIGN',0.0,0.0
        if abs(yaw_error)<0.006: return 'DONE',0.0,0.0
        return 'FINAL',0.0,clamp(2.4*yaw_error,-w_max,w_max)
    return 'DONE',0.0,0.0
