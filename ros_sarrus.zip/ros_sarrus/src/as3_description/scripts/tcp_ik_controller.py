#!/usr/bin/env python3
"""Assem3 TCP position control in base_link, no Gazebo and NO EKF.

Only publishes joint position requests. V4.7 virtual_mobile_base remains the
single /tf owner, preventing the previously observed Mobile Base jitter.
"""
import csv
import math
import time
from datetime import datetime
from pathlib import Path

import rclpy
from rclpy.node import Node
from ament_index_python.packages import get_package_share_directory
from geometry_msgs.msg import PointStamped, Twist
from sensor_msgs.msg import JointState
from std_msgs.msg import Empty, Float64MultiArray, String
from visualization_msgs.msg import Marker, MarkerArray
from as3_kinematics import ARM_NAMES, RobotKinematics


class TCPController(Node):
    def __init__(self):
        super().__init__('as3_tcp_ik_controller')
        urdf=Path(get_package_share_directory('as3_description'))/'urdf/as3_movable.urdf'
        self.kin=RobotKinematics(urdf)
        self.current={n:0.0 for n in ARM_NAMES}
        self.have_joint_state=False
        self.base_moving=False
        self.last_base_cmd=0.0
        self.goal=None
        self.target=None
        self.start=None
        self.end=None
        self.started=0.0
        self.duration=1.0
        self.last_report=0.0
        self.trail=[]
        self.tolerance=0.002
        self.allow_sarrus=False
        self.log_path=Path.home()/'.ros/as3_tcp_trials.csv'
        self.pub=self.create_publisher(JointState,'/as3/ik_joint_command',10)
        self.status_pub=self.create_publisher(String,'/as3/tcp_status',10)
        self.point_pub=self.create_publisher(PointStamped,'/as3/tcp_current',10)
        self.marker_pub=self.create_publisher(MarkerArray,'/as3/tcp_markers',10)
        self.create_subscription(JointState,'/joint_states',self.on_joint,10)
        self.create_subscription(Twist,'/cmd_vel',self.on_base_cmd,10)
        self.create_subscription(Float64MultiArray,'/as3/tcp_goal',self.on_goal,10)
        self.create_subscription(Empty,'/as3/tcp_stop',self.on_stop,10)
        self.create_subscription(Empty,'/as3/tcp_manual',self.on_manual,10)
        self.create_timer(1/30.0,self.step)
        self.create_timer(0.12,self.publish_markers)
        self.report('Sẵn sàng. Tọa độ TCP tính trong base_link (m).')

    def report(self,text):
        msg=String();msg.data=text
        self.status_pub.publish(msg)
        self.get_logger().info(text)

    def on_base_cmd(self,msg):
        self.base_moving=(abs(msg.linear.x)>0.0001 or abs(msg.angular.z)>0.0001)
        self.last_base_cmd=time.monotonic()
        if self.base_moving and self.start is not None:
            self.on_stop(None)
            self.report('Đã giữ TCP vì Mobile Base đang di chuyển. Bấm STOP Base trước.')

    def on_joint(self,msg):
        for n,p in zip(msg.name,msg.position):
            if n in self.current and math.isfinite(p):
                self.current[n]=float(p)
        self.have_joint_state=all(name in msg.name for name in ARM_NAMES)

    def publish_pose(self,q):
        msg=JointState()
        msg.header.stamp=self.get_clock().now().to_msg()
        msg.name=list(ARM_NAMES)
        msg.position=[q[n] for n in ARM_NAMES]
        self.pub.publish(msg)

    def on_goal(self,msg):
        if len(msg.data)!=4 or not all(math.isfinite(v) for v in msg.data):
            self.report('LỖI: Cần X, Y, Z và tùy chọn Sarrus hợp lệ.');return
        if not self.have_joint_state:
            self.report('Chưa nhận đủ /joint_states; thử lại khi robot đã hiển thị.');return
        if self.base_moving and time.monotonic()-self.last_base_cmd < 0.6:
            self.report('DỪNG MOBILE BASE trước khi gửi mục tiêu TCP.');return
        target=tuple(float(x) for x in msg.data[:3])
        allow_sarrus=bool(msg.data[3]>=0.5)
        self.allow_sarrus=allow_sarrus
        # Freeze at current pose before solving a new target.
        if self.start is not None:
            self.start=None;self.end=None
            self.publish_pose(dict(self.current))
        self.report('Đang giải IK từ URDF Assem3...')
        result,error=self.kin.ik(target,self.current,allow_sarrus,self.tolerance)
        if result is None:
            self.target=target
            self.trail=[]
            self.log_trial(None,None,None,False,near_error=error)
            self.report('KHÔNG TỚI ĐƯỢC: sai số nghiệm gần nhất %.1f mm. Giữ nguyên robot. Đã ghi CSV.'%(1000*error))
            return
        self.target=target
        self.start=dict(self.current)
        self.end=dict(result)
        delta=[abs(self.end[n]-self.start[n]) for n in ARM_NAMES]
        # Cubic smoothstep max velocity = 1.5 * |delta| / duration.
        self.duration=max(1.5,1.5*delta[0]/0.028,
                          *(1.5*d/0.55 for d in delta[1:]))
        self.started=time.monotonic()
        self.last_report=self.started
        self.trail=[]
        for i in range(31):
            u=i/30.0
            s=u*u*(3-2*u)
            qi={n:self.start[n]+(self.end[n]-self.start[n])*s for n in ARM_NAMES}
            self.trail.append(self.kin.fk(qi))
        self.report('Đã tìm nghiệm IK (%.1f mm), đang chạy quỹ đạo %.1f s; Sarrus %s.'%
                    (error*1000,self.duration,'BẬT' if allow_sarrus else 'KHÓA'))

    def log_trial(self,actual,error,joints,success,near_error=None):
        try:
            self.log_path.parent.mkdir(parents=True,exist_ok=True)
            new_file=not self.log_path.is_file() or self.log_path.stat().st_size==0
            with self.log_path.open('a',encoding='utf-8',newline='') as fp:
                w=csv.writer(fp)
                if new_file:
                    w.writerow(['timestamp','success','target_x_m','target_y_m','target_z_m',
                                'fk_x_m','fk_y_m','fk_z_m','fk_error_mm',
                                'best_ik_residual_mm','allow_sarrus','motion_duration_s']+list(ARM_NAMES))
                w.writerow([datetime.now().isoformat(timespec='seconds'),int(success),
                            *[round(v,6) for v in self.target],
                            *([round(v,6) for v in actual] if actual is not None else ['', '', '']),
                            round(1000*error,3) if error is not None else '',
                            round(1000*near_error,3) if near_error is not None else '',
                            int(self.allow_sarrus),round(self.duration,3) if success else 0.0,
                            *([round(joints[n],6) for n in ARM_NAMES] if joints else ['']*len(ARM_NAMES))])
        except OSError as exc:
            self.get_logger().warning('CSV not saved: %s'%exc)

    def on_stop(self,_):
        self.start=None;self.end=None
        # Keep auto mode latched to prevent stale sliders from snapping the arm.
        self.publish_pose(dict(self.current))
        self.report('Đã dừng, giữ nguyên tư thế. Bấm MANUAL để trở lại thanh trượt.')

    def on_manual(self,_):
        self.start=None;self.end=None
        self.target=None;self.trail=[]
        self.report('Đã trả quyền điều khiển cho thanh trượt (tư thế có thể đổi về vị trí slider).')

    def step(self):
        if self.start is not None:
            u=min(1.0,(time.monotonic()-self.started)/self.duration)
            s=u*u*(3.0-2.0*u)
            qi={n:self.start[n]+(self.end[n]-self.start[n])*s for n in ARM_NAMES}
            self.publish_pose(qi)
            if u>=1.0:
                self.start=None
                self.end=None
                self.publish_pose(qi)
                measured=self.kin.fk(qi)
                e=math.dist(measured,self.target)
                self.log_trial(measured,e,qi,True,near_error=e)
                self.report('HOÀN THÀNH: sai số TCP theo động học URDF %.2f mm. CSV: ~/.ros/as3_tcp_trials.csv'%(e*1000))
            elif time.monotonic()-self.last_report>1.0:
                self.last_report=time.monotonic()
                self.report('Đang di chuyển TCP: %d%%'%(100*u))
        if self.have_joint_state:
            pt=self.kin.fk(self.current)
            msg=PointStamped()
            msg.header.frame_id='base_link'
            msg.header.stamp=self.get_clock().now().to_msg()
            msg.point.x,msg.point.y,msg.point.z=pt
            self.point_pub.publish(msg)

    @staticmethod
    def marker(ns,idx,kind,color,xyz,size):
        m=Marker()
        m.header.frame_id='base_link'
        m.header.stamp.sec=0;m.header.stamp.nanosec=0
        m.ns=ns;m.id=idx;m.action=Marker.ADD;m.type=kind
        m.frame_locked=True
        m.pose.orientation.w=1.0
        m.pose.position.x,m.pose.position.y,m.pose.position.z=xyz
        m.scale.x,m.scale.y,m.scale.z=size
        m.color.r,m.color.g,m.color.b,m.color.a=color
        return m

    def publish_markers(self):
        arr=MarkerArray()
        current_pt=self.kin.fk(self.current)
        arr.markers.append(self.marker('tcp_actual',0,Marker.SPHERE,(0.1,0.85,0.45,1),current_pt,(0.016,)*3))
        if self.target:
            arr.markers.append(self.marker('tcp_target',1,Marker.SPHERE,(1,0.30,0.10,1),self.target,(0.022,)*3))
            line=self.marker('tcp_error',2,Marker.LINE_LIST,(1,0.86,0.05,0.95),(0,0,0),(.003,0,0))
            for p in (current_pt,self.target):
                from geometry_msgs.msg import Point
                pt=Point();pt.x,pt.y,pt.z=p
                line.points.append(pt)
            arr.markers.append(line)
        if len(self.trail)>1:
            path=self.marker('tcp_planned_path',3,Marker.LINE_STRIP,(0.0,0.65,1,0.75),(0,0,0),(.002,0,0))
            from geometry_msgs.msg import Point
            for p in self.trail:
                pt=Point();pt.x,pt.y,pt.z=p
                path.points.append(pt)
            arr.markers.append(path)
        # Remove stale target/path when switching back to manual mode.
        present={(m.ns,m.id) for m in arr.markers}
        for ns,idx in (('tcp_target',1),('tcp_error',2),('tcp_planned_path',3)):
            if (ns,idx) not in present:
                dead=Marker();dead.header.frame_id='base_link'
                dead.ns=ns;dead.id=idx;dead.action=Marker.DELETE
                arr.markers.append(dead)
        self.marker_pub.publish(arr)


def main(args=None):
    rclpy.init(args=args)
    node=TCPController()
    try:rclpy.spin(node)
    except KeyboardInterrupt:pass
    finally:
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()

if __name__=='__main__':main()
