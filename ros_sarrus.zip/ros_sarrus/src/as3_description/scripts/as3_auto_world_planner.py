#!/usr/bin/env python3
"""Heuristic base-stop candidates for an RViz-only mobile manipulator.

Candidate selection is *not* navigation/collision planning.  Geometry is in
world metres/radians; each candidate is validated by the Assem3 Jacobian IK.
"""
import math
from as3_auto_math import wrap


def candidate_stops(target_xyz, current_base, max_drive_m=5.0):
    """Return [(x_world, y_world, yaw_rad), ...] sorted by travel cost.

    We favor minimal translation, then yaw change.  Stop poses are generated
    by placing the target at typical horizontal TCP positions of the Assem3
    CAD arm, in the corresponding proposed base frame.  Kinematic validity
    (including Z/theta/joint bounds) is checked by the caller's real IK.
    """
    tx,ty,_=target_xyz
    x0,y0,_,yaw0=current_base
    bearing=math.atan2(ty-y0,tx-x0) if math.hypot(ty-y0,tx-x0)>1e-7 else yaw0
    # Candidate orientations: retain the current one whenever possible;
    # optionally rotate toward the goal when the arm's yaw alone cannot reach.
    heading=bearing-math.atan2(0.055,0.40)
    yaw_list=[yaw0,heading,bearing]
    for degree in (15,-15,30,-30,60,-60,90,-90):
        yaw_list.extend([yaw0+math.radians(degree),heading+math.radians(degree)])
    yaw_list.extend([yaw0+math.pi,heading+math.pi])

    # Test in-place rotation before travelling (the exact present pose
    # without rotation is separately checked by the caller).
    proposed=[]
    # A base yaw change cannot change radial TCP distance. Skip in-place
    # rotation trials for targets well outside the arm's current XY reach.
    if math.hypot(tx-x0,ty-y0)<0.54:
        for yaw in (heading, yaw0+math.radians(30),yaw0-math.radians(30)):
            if abs(wrap(yaw-yaw0))>0.012:
                proposed.append((x0,y0,wrap(yaw)))

    # Candidate local X around the horizontal folded-arm reach and local Y
    # around the CAD zero configuration; IK validates the actual reach.
    for yaw in yaw_list:
        c,s=math.cos(yaw),math.sin(yaw)
        for lx in (0.46,0.44,0.42,0.40,0.38,0.48,0.36,0.32,0.52,0.28,0.24):
            for ly in (0.055,0.0,-0.065,0.13):
                bx=tx-(c*lx-s*ly)
                by=ty-(s*lx+c*ly)
                if math.hypot(bx-x0,by-y0)>max_drive_m:
                    continue
                if abs(bx)>8 or abs(by)>8:
                    continue
                proposed.append((bx,by,wrap(yaw)))

    found={}
    for bx,by,yaw in proposed:
        # Quantize only for duplicate removal, never for the returned stop.
        key=(round(bx,4),round(by,4),round(wrap(yaw),3))
        if key in found:continue
        d=math.hypot(bx-x0,by-y0)
        rotation=abs(wrap(yaw-yaw0))
        # Drive cost dominates, with a modest cost on turning in-place.
        # Prefer a comfortable 0.44 m TCP extension over far-stretched or
        # tightly folded configurations when travel costs are similar.
        c,s=math.cos(yaw),math.sin(yaw)
        lx=c*(tx-bx)+s*(ty-by)
        ly=-s*(tx-bx)+c*(ty-by)
        score=d+0.10*rotation+0.35*abs(lx-0.44)+0.10*abs(ly-0.055)
        inplace=d<1e-5
        # The central CAD arm configurations around x=0.40..0.46, y=0.055
        # have much better conditioning than stretching to x≈0.52. Try
        # those candidates early, then fall back to the broader search.
        comfortable=0.399<=lx<=0.461 and abs(ly-0.055)<0.004
        near_heading=min(abs(wrap(yaw-yaw0)),abs(wrap(yaw-heading)))<0.09
        tier=(0 if inplace else 1 if comfortable and near_heading else 2)
        found[key]=(tier,score,(bx,by,yaw))
    return [candidate for tier,score,candidate in sorted(found.values(),key=lambda z:(z[0],z[1]))]
