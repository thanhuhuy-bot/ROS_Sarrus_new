#!/usr/bin/env python3
"""Assem3 RViz-only Base Control, publishing ROS 2 /cmd_vel.

Click a direction to start continuous motion; STOP or Esc to stop.
This interface is for virtual RViz demo only, NOT a motor controller.
"""
import tkinter as tk
from tkinter import ttk

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


class BaseControl(Node):
    def __init__(self):
        super().__init__('as3_base_control_gui')
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.mode = 'stop'
        self.closing = False
        self.root = tk.Tk()
        self.root.title('Base Control - Assem3 (RViz)')
        self.root.resizable(False, False)
        self.root.configure(padx=12, pady=8)

        settings = ttk.LabelFrame(self.root, text='Base Control', padding=8)
        settings.grid(row=0, column=0, sticky='nsew')
        ttk.Label(settings, text='Linear Speed (m/s):').grid(row=0, column=0, sticky='w', pady=3)
        self.linear_value = tk.StringVar(value='0.20')
        ttk.Entry(settings, width=8, textvariable=self.linear_value).grid(row=0, column=1, padx=4)
        ttk.Label(settings, text='Angular Speed (rad/s):').grid(row=0, column=2, sticky='w', padx=(8, 0))
        self.angular_value = tk.StringVar(value='0.50')
        ttk.Entry(settings, width=8, textvariable=self.angular_value).grid(row=0, column=3, padx=4)

        controls = ttk.Frame(settings)
        controls.grid(row=1, column=0, columnspan=4, pady=(9, 0))
        self.buttons = {}
        for name, label, r, c in [
            ('forward', '▲ Forward', 0, 1),
            ('left', '◀ Turn Left', 1, 0),
            ('stop', '■ STOP', 1, 1),
            ('right', 'Turn Right ▶', 1, 2),
            ('backward', '▼ Backward', 2, 1),
        ]:
            b = tk.Button(controls, text=label, width=12, height=1,
                          command=lambda n=name: self.set_mode(n),
                          bg='#f1f1f1', fg='#222', relief=tk.RAISED)
            b.grid(row=r, column=c, padx=4, pady=3)
            self.buttons[name] = b
        self.buttons['stop'].configure(fg='red', font=('TkDefaultFont', 9, 'bold'))
        self.status = tk.StringVar(value='Đang dừng - RViz only')
        ttk.Label(settings, textvariable=self.status).grid(row=2, column=0, columnspan=4, pady=(8, 0))
        ttk.Label(settings, text='Click để chạy liên tục; STOP hoặc Esc để dừng.').grid(
            row=3, column=0, columnspan=4, pady=(3, 0))
        self.root.bind('<Escape>', lambda _: self.set_mode('stop'))
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        self.paint()
        self.root.after(50, self.tick)
        self.get_logger().info('Assem3 base control GUI publishing /cmd_vel (RViz only)')

    @staticmethod
    def speed(value, limit):
        try:
            n = abs(float(value))
            return min(n, limit) if n == n and n != float('inf') else 0.0
        except (ValueError, TypeError):
            return 0.0

    def paint(self):
        for name, button in self.buttons.items():
            button.configure(relief=tk.SUNKEN if name == self.mode else tk.RAISED,
                             bg='#c9e8ff' if name == self.mode and name != 'stop' else '#f1f1f1')
        self.status.set({
            'forward': 'Đang tiến', 'backward': 'Đang lùi',
            'left': 'Đang quay trái', 'right': 'Đang quay phải',
            'stop': 'Đang dừng - RViz only',
        }[self.mode])

    def set_mode(self, mode):
        self.mode = mode
        self.paint()
        self.publish_command()

    def publish_command(self):
        msg = Twist()
        linear = self.speed(self.linear_value.get(), 1.0)
        angular = self.speed(self.angular_value.get(), 2.0)
        if self.mode == 'forward': msg.linear.x = linear
        if self.mode == 'backward': msg.linear.x = -linear
        if self.mode == 'left': msg.angular.z = angular
        if self.mode == 'right': msg.angular.z = -angular
        self.publisher.publish(msg)

    def tick(self):
        if self.closing: return
        self.publish_command()
        self.root.after(50, self.tick)

    def close(self):
        if self.closing: return
        self.mode = 'stop'
        self.publish_command()
        self.closing = True
        self.root.destroy()


def main(args=None):
    rclpy.init(args=args)
    node = BaseControl()
    try:
        node.root.mainloop()
    except KeyboardInterrupt:
        node.close()
    finally:
        if not node.closing: node.close()
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()

if __name__ == '__main__':
    main()
