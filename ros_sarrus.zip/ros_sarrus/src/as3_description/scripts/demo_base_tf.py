#!/usr/bin/env python3
"""Demo-only periodic TF world -> base_link for RViz preview."""
import math,time
import rclpy
from rclpy.node import Node
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped

class DemoBase(Node):
    def __init__(self):
        super().__init__('as3_demo_base_tf')
        self.tfpub=TransformBroadcaster(self)
        self.started=time.monotonic()
        self.timer=self.create_timer(0.04,self.update)
    def update(self):
        t=time.monotonic()-self.started
        yaw=0.15*math.sin(0.14*t)
        tr=TransformStamped()
        tr.header.stamp=self.get_clock().now().to_msg()
        tr.header.frame_id='world'
        tr.child_frame_id='base_link'
        tr.transform.translation.x=0.10*math.sin(0.12*t)
        tr.transform.translation.y=0.025*math.sin(0.08*t)
        tr.transform.translation.z=0.11
        tr.transform.rotation.z=math.sin(0.5*yaw)
        tr.transform.rotation.w=math.cos(0.5*yaw)
        self.tfpub.sendTransform(tr)

def main(args=None):
    rclpy.init(args=args);node=DemoBase()
    try:rclpy.spin(node)
    except KeyboardInterrupt:pass
    finally:
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()
if __name__=='__main__':main()
