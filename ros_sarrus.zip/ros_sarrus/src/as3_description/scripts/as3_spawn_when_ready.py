#!/usr/bin/env python3
"""Wait for Gazebo Classic's /spawn_entity service before loading Assem3.

The previous launch called spawn_entity.py a fixed 4 seconds after startup.
That is too early on a slower VM. This node waits for Gazebo's factory
service, prints the precise spawn result, and retries transient failures.
It never publishes TF or joint states and does not alter any SolidWorks mesh.
"""
import argparse
import sys
import time
from pathlib import Path

import rclpy
from rclpy.node import Node
from gazebo_msgs.srv import SpawnEntity


class As3SpawnWhenReady(Node):
    def __init__(self, sdf_path, entity, wait_seconds):
        super().__init__('as3_gazebo_spawn_when_ready')
        self.sdf_path = Path(sdf_path)
        self.entity = entity
        self.wait_seconds = wait_seconds
        self.client = self.create_client(SpawnEntity, '/spawn_entity')

    def run(self):
        if not self.sdf_path.is_file():
            self.get_logger().error('SDF FILE MISSING: %s' % self.sdf_path)
            return 2
        xml = self.sdf_path.read_text(encoding='utf-8')
        if '<sdf' not in xml or self.entity not in xml:
            self.get_logger().error('SDF INVALID or entity missing in %s' % self.sdf_path)
            return 2

        self.get_logger().info('Waiting for Gazebo Classic /spawn_entity service...')
        deadline = time.monotonic() + self.wait_seconds
        notified = time.monotonic()
        while rclpy.ok() and time.monotonic() < deadline:
            if self.client.wait_for_service(timeout_sec=2.0):
                break
            if time.monotonic() - notified > 10:
                self.get_logger().warn('Still waiting for Gazebo server/factory...')
                notified = time.monotonic()
        else:
            self.get_logger().error(
                'NO /spawn_entity service: Gazebo server failed or factory plugin '
                'was not loaded. Check gzserver messages in launch terminal.')
            return 3

        for attempt in range(1, 4):
            if not rclpy.ok():
                return 130
            req = SpawnEntity.Request()
            req.name = self.entity
            req.xml = xml
            req.robot_namespace = '/'
            req.reference_frame = 'world'
            # Explicit identity quaternion; model pose is synchronized by
            # the existing Gazebo kinematic-mirror plugin.
            req.initial_pose.orientation.w = 1.0
            self.get_logger().info('Spawning %s (attempt %d/3)' % (self.entity, attempt))
            future = self.client.call_async(req)
            rclpy.spin_until_future_complete(self, future, timeout_sec=45.0)
            if future.done():
                try:
                    response = future.result()
                except Exception as exc:
                    self.get_logger().error('Spawn service error: %s' % exc)
                else:
                    message = str(response.status_message)
                    if response.success:
                        self.get_logger().info('SUCCESS: %s - %s' % (self.entity, message))
                        return 0
                    if 'already exist' in message.lower() or 'already spawned' in message.lower():
                        self.get_logger().warn('Model already present: %s' % message)
                        return 0
                    self.get_logger().error('Gazebo rejected model: %s' % message)
                    # Invalid SDF/plugin errors are not resolved by rapid retries.
                    if any(w in message.lower() for w in ('parse', 'invalid', 'sdf')):
                        return 4
            else:
                self.get_logger().warn('Timed out waiting for Gazebo spawn response')
            time.sleep(2.0)
        self.get_logger().error('SPAWN FAILED after 3 attempts. Check Gazebo server log.')
        return 5


def main(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--sdf', required=True)
    parser.add_argument('--entity', default='as3_solidworks')
    parser.add_argument('--wait-seconds', type=float, default=150.0)
    opts, ros_args = parser.parse_known_args(args)
    rclpy.init(args=ros_args)
    node = As3SpawnWhenReady(opts.sdf, opts.entity, opts.wait_seconds)
    try:
        result = node.run()
    except KeyboardInterrupt:
        result = 130
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
    return result


if __name__ == '__main__':
    sys.exit(main())
