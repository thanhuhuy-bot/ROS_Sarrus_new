from pathlib import Path
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def _build(context, *args, **kwargs):
    share = Path(get_package_share_directory('as3_description'))
    description = (share / 'urdf' / 'as3_movable.urdf').read_text(encoding='utf-8')
    demo = LaunchConfiguration('demo').perform(context).lower() in ('true', '1', 'yes')
    state_node = (Node(package='as3_description', executable='move_demo.py',
                       output='screen') if demo else
                  Node(package='joint_state_publisher_gui', executable='joint_state_publisher_gui',
                       output='screen', parameters=[{'robot_description': description}]))
    return [
        Node(package='tf2_ros', executable='static_transform_publisher',
             arguments=['--x','0','--y','0','--z','0.11',
                        '--roll','0','--pitch','0','--yaw','0',
                        '--frame-id','world','--child-frame-id','base_link'],
             output='screen') if not demo else
        Node(package='as3_description', executable='demo_base_tf.py', output='screen'),
        Node(package='robot_state_publisher', executable='robot_state_publisher',
             output='screen', parameters=[{'robot_description': description}]),
        state_node,
        Node(package='as3_description', executable='sarrus_visual.py', output='screen'),
        Node(package='rviz2', executable='rviz2', output='screen',
             arguments=['-d', str(share / 'rviz' / 'assem3.rviz')]),
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('demo', default_value='false',
            description='true: auto animation; false: joint_state_publisher_gui sliders'),
        OpaqueFunction(function=_build),
    ])
