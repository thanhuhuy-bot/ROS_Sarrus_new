from pathlib import Path
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def _start(context, *args, **kwargs):
    share = Path(get_package_share_directory('as3_description'))
    zup = LaunchConfiguration('z_up').perform(context).lower() in ('true', '1', 'yes')
    fn = 'assem3_ros_zup.urdf' if zup else 'assem3_solidworks.urdf'
    description = (share / 'urdf' / fn).read_text(encoding='utf-8')
    return [
        Node(package='robot_state_publisher', executable='robot_state_publisher',
             output='screen', parameters=[{'robot_description': description}]),
        Node(package='rviz2', executable='rviz2', output='screen',
             arguments=['-d', str(share / 'rviz' / 'assem3.rviz')]),
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('z_up', default_value='false',
                              description='Rotate SolidWorks Y-up frame by +90 deg about X for ROS Z-up view'),
        OpaqueFunction(function=_start),
    ])
