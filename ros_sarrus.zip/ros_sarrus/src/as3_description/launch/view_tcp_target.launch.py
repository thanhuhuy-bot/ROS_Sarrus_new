from pathlib import Path
from launch import LaunchDescription
from launch.actions import TimerAction
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    share = Path(get_package_share_directory('as3_description'))
    full_urdf = (share / 'urdf/as3_movable.urdf').read_text(encoding='utf-8')
    arm_only_urdf = (share / 'urdf/as3_arm_sliders.urdf').read_text(encoding='utf-8')
    return LaunchDescription([
        Node(package='robot_state_publisher', executable='robot_state_publisher',
             parameters=[{'robot_description': full_urdf}],
             # Keep only static joints from RSP: dynamic joints published atomically by mobile node.
             remappings=[('/joint_states', '/as3_unused_joint_states_for_rsp')],
             output='screen'),
        # Slider GUI publishes /arm_joint_states only; mobile node merges all joints once.
        Node(package='joint_state_publisher_gui', executable='joint_state_publisher_gui',
             parameters=[{'robot_description': arm_only_urdf,
                          'zeros.joint_1_sarrus': 0.0,
                          'zeros.joint_2_yaw': 0.0,
                          'zeros.joint_3_shoulder': 0.0,
                          'zeros.joint_4_elbow': 0.0,
                          'zeros.joint_5_wrist': 0.0}],
             remappings=[('/joint_states', '/arm_joint_states')],
             output='screen'),
        # Click-to-drive window publishes /cmd_vel.
        Node(package='as3_description', executable='base_control_gui.py', output='screen'),
        # Publishes one world->base_link TF and full JointState with a shared timestamp.
        Node(package='as3_description', executable='virtual_mobile_base.py', output='screen'),
        Node(package='as3_description', executable='sarrus_visual.py', output='screen'),
        # GUI itself solves IK and publishes commands. No separate TCP controller.
        Node(package='rviz2', executable='rviz2',
             arguments=['-d', str(share / 'rviz/assem3_tcp.rviz')], output='screen'),
        # Start the TCP control last so the user can see the window above RViz.
        TimerAction(period=3.0, actions=[
            Node(package='as3_description', executable='tcp_target_gui.py', output='screen')
        ]),
    ])
