"""Assem3 autonomous TCP world in RViz + Gazebo Classic 11 (optional).
Gazebo is a visualization-kinematic mirror. ROS V4.7 owns the complete TF.
"""
import os
import sys
from pathlib import Path
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable, TimerAction, OpaqueFunction, LogInfo
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory, get_package_prefix


def _create(context, *args, **kwargs):
    share=Path(get_package_share_directory('as3_description'))
    try:
        plugin_prefix=Path(get_package_prefix('as3_gazebo_bridge'))
        gazebo_share=Path(get_package_share_directory('gazebo_ros'))
    except LookupError as e:
        raise RuntimeError('Gazebo Classic add-on not installed; see HUONG_DAN_GAZEBO_V50.md') from e
    from importlib.util import spec_from_file_location, module_from_spec
    import_path=str(Path(get_package_prefix('as3_description'))/'lib/as3_description/generate_gazebo_sdf.py')
    # Python script installed alongside other as3_description executables.
    script=Path(import_path)
    spec=spec_from_file_location('as3_gazebo_sdf_generator',script)
    # Import generator needs sibling sarrus_rigid_math on Python import path.
    sys.path.insert(0,str(script.parent))
    mod=module_from_spec(spec)
    spec.loader.exec_module(mod)
    sdf=Path('/tmp/as3_solidworks_ros_humble_gazebo.sdf')
    mod.generate(share,sdf)
    gazlaunch=gazebo_share/'launch/gazebo.launch.py'
    if not gazlaunch.is_file():
        raise RuntimeError('gazebo_ros launch not found: '+str(gazlaunch))
    plugin_path=str(plugin_prefix/'lib')
    plugin_env=plugin_path+(':'+os.environ['GAZEBO_PLUGIN_PATH'] if os.environ.get('GAZEBO_PLUGIN_PATH') else '')
    # gazebo_ros gzserver.launch.py reads os.environ while composing additional_env.
    os.environ['GAZEBO_PLUGIN_PATH'] = plugin_env
    urdf=(share/'urdf/as3_movable.urdf').read_text(encoding='utf-8')
    arm_urdf=(share/'urdf/as3_arm_sliders.urdf').read_text(encoding='utf-8')
    return [
        SetEnvironmentVariable('GAZEBO_PLUGIN_PATH',plugin_env),
        IncludeLaunchDescription(PythonLaunchDescriptionSource(str(gazlaunch)),
                                 launch_arguments={'world':str(share/'worlds/as3_empty.world')}.items()),
        # Gazebo Classic factory spawn. The plugin mirrors /tf and /joint_states.
        # Service-aware spawn: no fixed startup delay (VMs can be slow).
        Node(package='as3_description', executable='as3_spawn_when_ready.py',
             arguments=['--sdf', str(sdf), '--entity', 'as3_solidworks',
                        '--wait-seconds', '150'], output='screen'),
        Node(package='robot_state_publisher',executable='robot_state_publisher',
             parameters=[{'robot_description':urdf}],
             remappings=[('/joint_states','/as3_unused_joint_states_for_rsp')],output='screen'),
        Node(package='joint_state_publisher_gui',executable='joint_state_publisher_gui',
             parameters=[{'robot_description':arm_urdf,
                          'zeros.joint_1_sarrus':0.0,
                          'zeros.joint_2_yaw':0.0,
                          'zeros.joint_3_shoulder':0.0,
                          'zeros.joint_4_elbow':0.0,
                          'zeros.joint_5_wrist':0.0}],
             remappings=[('/joint_states','/arm_joint_states')],output='screen'),
        Node(package='as3_description',executable='virtual_mobile_base.py',output='screen'),
        Node(package='as3_description',executable='sarrus_visual.py',output='screen'),
        Node(package='as3_description',executable='gazebo_pose_bridge.py',output='screen'),
        Node(package='rviz2',executable='rviz2',
             arguments=['-d',str(share/'rviz/assem3_auto.rviz')],output='screen'),
        TimerAction(period=9.0,actions=[
            Node(package='as3_description',executable='auto_world_tcp_gui.py',
                 additional_env={'AS3_GAZEBO_MODE':'1'},output='screen')]),
        LogInfo(msg='Assem3: Gazebo Classic 11 + GUI TCP WORLD XYZ theta. Kinematic display only.'),
    ]


def generate_launch_description():
    return LaunchDescription([OpaqueFunction(function=_create)])
